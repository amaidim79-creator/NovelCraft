import React, { useEffect } from "react";
import { View, StyleSheet } from "react-native";
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withTiming,
  withRepeat,
  withSequence,
  Easing,
  interpolate,
} from "react-native-reanimated";
import { Feather } from "@expo/vector-icons";

import { ThemedText } from "@/components/ThemedText";
import { ThemedView } from "@/components/ThemedView";
import { useTheme } from "@/hooks/useTheme";
import { Spacing, BorderRadius } from "@/constants/theme";

export default function LoadingScreen() {
  const { theme } = useTheme();
  const progress = useSharedValue(0);
  const pulse = useSharedValue(0);

  useEffect(() => {
    progress.value = withRepeat(
      withTiming(1, { duration: 1500, easing: Easing.inOut(Easing.ease) }),
      -1,
      true
    );
    pulse.value = withRepeat(
      withSequence(
        withTiming(1, { duration: 800, easing: Easing.inOut(Easing.ease) }),
        withTiming(0, { duration: 800, easing: Easing.inOut(Easing.ease) })
      ),
      -1
    );
  }, []);

  const iconStyle = useAnimatedStyle(() => ({
    transform: [
      {
        scale: interpolate(pulse.value, [0, 1], [1, 1.1]),
      },
    ],
    opacity: interpolate(pulse.value, [0, 1], [0.8, 1]),
  }));

  const dotStyle = (index: number) =>
    useAnimatedStyle(() => {
      const offset = index * 0.2;
      const adjustedProgress = (progress.value + offset) % 1;
      return {
        opacity: interpolate(adjustedProgress, [0, 0.5, 1], [0.3, 1, 0.3]),
        transform: [
          {
            translateY: interpolate(adjustedProgress, [0, 0.5, 1], [0, -8, 0]),
          },
        ],
      };
    });

  return (
    <ThemedView style={styles.container}>
      <View style={styles.content}>
        <Animated.View
          style={[
            styles.iconContainer,
            { backgroundColor: theme.primary },
            iconStyle,
          ]}
        >
          <Feather name="feather" size={40} color="#FFFFFF" />
        </Animated.View>

        <ThemedText type="h2" style={styles.title}>
          NovelCraft
        </ThemedText>

        <View style={styles.loadingDots}>
          {[0, 1, 2].map((index) => (
            <Animated.View
              key={index}
              style={[
                styles.dot,
                { backgroundColor: theme.primary },
                dotStyle(index),
              ]}
            />
          ))}
        </View>

        <ThemedText
          type="small"
          style={[styles.tagline, { color: theme.textTertiary }]}
        >
          Your stories, beautifully crafted
        </ThemedText>
      </View>
    </ThemedView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  content: {
    alignItems: "center",
  },
  iconContainer: {
    width: 80,
    height: 80,
    borderRadius: BorderRadius.lg,
    justifyContent: "center",
    alignItems: "center",
    marginBottom: Spacing.xl,
  },
  title: {
    marginBottom: Spacing["3xl"],
  },
  loadingDots: {
    flexDirection: "row",
    gap: Spacing.sm,
    marginBottom: Spacing["3xl"],
  },
  dot: {
    width: 10,
    height: 10,
    borderRadius: 5,
  },
  tagline: {
    textAlign: "center",
  },
});
