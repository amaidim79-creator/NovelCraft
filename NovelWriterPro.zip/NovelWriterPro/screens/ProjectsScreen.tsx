import React, { useState, useCallback } from "react";
import {
  View,
  StyleSheet,
  Pressable,
  Modal,
  TextInput,
  Alert,
  ActivityIndicator,
  ScrollView,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useBottomTabBarHeight } from "@react-navigation/bottom-tabs";
import { Feather } from "@expo/vector-icons";
import Animated, {
  useAnimatedStyle,
  useSharedValue,
  withSpring,
} from "react-native-reanimated";
import { useNavigation } from "@react-navigation/native";
import { BottomTabNavigationProp } from "@react-navigation/bottom-tabs";

import { ThemedText } from "@/components/ThemedText";
import { ThemedView } from "@/components/ThemedView";
import { ScreenScrollView } from "@/components/ScreenScrollView";
import { Button } from "@/components/Button";
import { useTheme } from "@/hooks/useTheme";
import { useApp } from "@/context/AppContext";
import { useAuth } from "@/context/AuthContext";
import { Spacing, BorderRadius } from "@/constants/theme";
import { MainTabParamList } from "@/navigation/MainTabNavigator";
import { Project } from "@/utils/storage";
import { shareExport } from "@/utils/export";

const GENRES = ["Fantasy", "Sci-Fi", "Romance", "Mystery", "Horror", "Thriller", "Literary", "Historical"];

const AnimatedPressable = Animated.createAnimatedComponent(Pressable);

function ProjectCard({
  project,
  onPress,
  onLongPress,
  onExport,
  theme,
}: {
  project: Project;
  onPress: () => void;
  onLongPress: () => void;
  onExport: () => void;
  theme: any;
}) {
  const scale = useSharedValue(1);

  const animatedStyle = useAnimatedStyle(() => ({
    transform: [{ scale: scale.value }],
  }));

  const getGenreIcon = (genre: string) => {
    switch (genre.toLowerCase()) {
      case "fantasy":
        return "compass";
      case "sci-fi":
        return "cpu";
      case "romance":
        return "heart";
      case "mystery":
        return "search";
      case "horror":
        return "moon";
      case "thriller":
        return "zap";
      default:
        return "book-open";
    }
  };

  const progress = project.targetWordCount > 0 
    ? Math.min((project.wordCount / project.targetWordCount) * 100, 100) 
    : 0;

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));
    
    if (diffDays === 0) return "Today";
    if (diffDays === 1) return "Yesterday";
    if (diffDays < 7) return `${diffDays} days ago`;
    return date.toLocaleDateString();
  };

  return (
    <AnimatedPressable
      onPress={onPress}
      onLongPress={onLongPress}
      onPressIn={() => {
        scale.value = withSpring(0.98, { damping: 15, stiffness: 150 });
      }}
      onPressOut={() => {
        scale.value = withSpring(1, { damping: 15, stiffness: 150 });
      }}
      style={[
        styles.projectCard,
        { backgroundColor: theme.backgroundDefault },
        animatedStyle,
      ]}
    >
      <View style={styles.projectCardHeader}>
        <View
          style={[
            styles.genreIconContainer,
            { backgroundColor: theme.primary + "20" },
          ]}
        >
          <Feather
            name={getGenreIcon(project.genre) as any}
            size={20}
            color={theme.primary}
          />
        </View>
        <View style={styles.projectCardActions}>
          <Pressable
            style={[styles.exportIconButton, { backgroundColor: theme.backgroundSecondary }]}
            onPress={(e) => {
              e.stopPropagation();
              onExport();
            }}
          >
            <Feather name="share" size={14} color={theme.textSecondary} />
          </Pressable>
          <View style={[styles.genreTag, { backgroundColor: theme.backgroundSecondary }]}>
            <ThemedText type="small" style={{ color: theme.textSecondary }}>
              {project.genre}
            </ThemedText>
          </View>
        </View>
      </View>

      <ThemedText type="h3" numberOfLines={2} style={styles.projectTitle}>
        {project.title}
      </ThemedText>

      {project.description ? (
        <ThemedText
          type="small"
          numberOfLines={2}
          style={{ color: theme.textSecondary, marginBottom: Spacing.md }}
        >
          {project.description}
        </ThemedText>
      ) : null}

      <View style={styles.projectStats}>
        <ThemedText type="small" style={{ color: theme.textTertiary }}>
          {project.wordCount.toLocaleString()} words
        </ThemedText>
        <ThemedText type="small" style={{ color: theme.textTertiary }}>
          {formatDate(project.updatedAt)}
        </ThemedText>
      </View>

      {project.targetWordCount > 0 ? (
        <View style={styles.progressContainer}>
          <View
            style={[
              styles.progressBar,
              { backgroundColor: theme.backgroundSecondary },
            ]}
          >
            <View
              style={[
                styles.progressFill,
                {
                  backgroundColor: theme.success,
                  width: `${progress}%`,
                },
              ]}
            />
          </View>
          <ThemedText type="small" style={{ color: theme.textTertiary }}>
            {Math.round(progress)}%
          </ThemedText>
        </View>
      ) : null}
    </AnimatedPressable>
  );
}

export default function ProjectsScreen() {
  const { theme, isDark } = useTheme();
  const insets = useSafeAreaInsets();
  const tabBarHeight = useBottomTabBarHeight();
  const navigation = useNavigation<BottomTabNavigationProp<MainTabParamList>>();
  const { user, signOut } = useAuth();
  const {
    projects,
    currentProject,
    setCurrentProject,
    addProject,
    deleteProject,
    getProjectChapters,
    isLoading,
  } = useApp();

  const [showNewProject, setShowNewProject] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [showExportModal, setShowExportModal] = useState(false);
  const [exportingProject, setExportingProject] = useState<Project | null>(null);
  const [newProjectTitle, setNewProjectTitle] = useState("");
  const [newProjectGenre, setNewProjectGenre] = useState("Fantasy");
  const [newProjectDescription, setNewProjectDescription] = useState("");
  const [newProjectTarget, setNewProjectTarget] = useState("");
  const [isSaving, setIsSaving] = useState(false);
  const [isExporting, setIsExporting] = useState(false);

  const handleCreateProject = async () => {
    if (!newProjectTitle.trim()) {
      Alert.alert("Error", "Please enter a project title");
      return;
    }

    setIsSaving(true);
    try {
      const project = await addProject({
        title: newProjectTitle.trim(),
        genre: newProjectGenre,
        description: newProjectDescription.trim(),
        wordCount: 0,
        targetWordCount: parseInt(newProjectTarget) || 50000,
      });
      setCurrentProject(project);
      setShowNewProject(false);
      setNewProjectTitle("");
      setNewProjectDescription("");
      setNewProjectTarget("");
      navigation.navigate("WriteTab");
    } catch (error) {
      Alert.alert("Error", "Failed to create project");
    } finally {
      setIsSaving(false);
    }
  };

  const handleSelectProject = (project: Project) => {
    setCurrentProject(project);
    navigation.navigate("WriteTab");
  };

  const handleDeleteProject = (project: Project) => {
    Alert.alert(
      "Delete Project",
      `Are you sure you want to delete "${project.title}"? This cannot be undone.`,
      [
        { text: "Cancel", style: "cancel" },
        {
          text: "Delete",
          style: "destructive",
          onPress: () => deleteProject(project.id),
        },
      ]
    );
  };

  const handleExportProject = (project: Project) => {
    setExportingProject(project);
    setShowExportModal(true);
  };

  const handleExport = async (format: "txt" | "html") => {
    if (!exportingProject) return;

    setIsExporting(true);
    try {
      const chapters = getProjectChapters(exportingProject.id);
      const result = await shareExport(exportingProject, chapters, format);
      if (!result.success) {
        Alert.alert("Export Failed", result.error || "Something went wrong");
      }
      setShowExportModal(false);
      setExportingProject(null);
    } catch (error) {
      Alert.alert("Export Failed", "Something went wrong. Please try again.");
    } finally {
      setIsExporting(false);
    }
  };

  const handleSignOut = () => {
    Alert.alert(
      "Sign Out",
      "Are you sure you want to sign out?",
      [
        { text: "Cancel", style: "cancel" },
        {
          text: "Sign Out",
          style: "destructive",
          onPress: () => signOut(),
        },
      ]
    );
  };

  const totalWords = projects.reduce((sum, p) => sum + p.wordCount, 0);

  if (isLoading) {
    return (
      <ThemedView style={styles.loadingContainer}>
        <ActivityIndicator size="large" color={theme.primary} />
      </ThemedView>
    );
  }

  return (
    <ThemedView style={styles.container}>
      <View style={[styles.header, { paddingTop: insets.top + Spacing.lg }]}>
        <View style={styles.headerContent}>
          <View style={styles.logoContainer}>
            <View style={[styles.logoIcon, { backgroundColor: theme.primary }]}>
              <Feather name="feather" size={20} color="#FFFFFF" />
            </View>
            <ThemedText type="h1">NovelCraft</ThemedText>
          </View>
          <Pressable
            style={[styles.settingsButton, { backgroundColor: theme.backgroundDefault }]}
            onPress={() => setShowSettings(true)}
          >
            <Feather name="settings" size={20} color={theme.text} />
          </Pressable>
        </View>
      </View>

      <ScreenScrollView
        contentContainerStyle={[
          styles.scrollContent,
          { paddingBottom: tabBarHeight + Spacing.xl + 80 },
        ]}
      >
        <View
          style={[
            styles.statsCard,
            { backgroundColor: theme.backgroundDefault },
          ]}
        >
          <View style={styles.statItem}>
            <ThemedText type="h2" style={{ color: theme.primary }}>
              {projects.length}
            </ThemedText>
            <ThemedText type="small" style={{ color: theme.textSecondary }}>
              Projects
            </ThemedText>
          </View>
          <View style={[styles.statDivider, { backgroundColor: theme.border }]} />
          <View style={styles.statItem}>
            <ThemedText type="h2" style={{ color: theme.success }}>
              {totalWords.toLocaleString()}
            </ThemedText>
            <ThemedText type="small" style={{ color: theme.textSecondary }}>
              Total Words
            </ThemedText>
          </View>
        </View>

        {currentProject ? (
          <View style={styles.currentProjectSection}>
            <ThemedText type="h4" style={styles.sectionTitle}>
              Continue Writing
            </ThemedText>
            <ProjectCard
              project={currentProject}
              onPress={() => navigation.navigate("WriteTab")}
              onLongPress={() => handleDeleteProject(currentProject)}
              onExport={() => handleExportProject(currentProject)}
              theme={theme}
            />
          </View>
        ) : null}

        <View style={styles.projectsSection}>
          <ThemedText type="h4" style={styles.sectionTitle}>
            {currentProject ? "All Projects" : "My Novels"}
          </ThemedText>

          {projects.length === 0 ? (
            <View
              style={[
                styles.emptyState,
                { backgroundColor: theme.backgroundDefault },
              ]}
            >
              <Feather name="book-open" size={48} color={theme.textTertiary} />
              <ThemedText
                type="body"
                style={{ color: theme.textSecondary, marginTop: Spacing.lg }}
              >
                No projects yet
              </ThemedText>
              <ThemedText
                type="small"
                style={{
                  color: theme.textTertiary,
                  textAlign: "center",
                  marginTop: Spacing.sm,
                }}
              >
                Tap the + button to start your first novel
              </ThemedText>
            </View>
          ) : (
            projects
              .filter((p) => p.id !== currentProject?.id)
              .sort(
                (a, b) =>
                  new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime()
              )
              .map((project) => (
                <ProjectCard
                  key={project.id}
                  project={project}
                  onPress={() => handleSelectProject(project)}
                  onLongPress={() => handleDeleteProject(project)}
                  onExport={() => handleExportProject(project)}
                  theme={theme}
                />
              ))
          )}
        </View>
      </ScreenScrollView>

      <Pressable
        style={[
          styles.fab,
          { backgroundColor: theme.primary, bottom: tabBarHeight + Spacing.xl },
        ]}
        onPress={() => setShowNewProject(true)}
      >
        <Feather name="plus" size={24} color="#FFFFFF" />
      </Pressable>

      <Modal
        visible={showNewProject}
        animationType="slide"
        presentationStyle="pageSheet"
        onRequestClose={() => setShowNewProject(false)}
      >
        <ThemedView style={styles.modalContainer}>
          <View style={styles.modalHeader}>
            <Pressable onPress={() => setShowNewProject(false)}>
              <Feather name="x" size={24} color={theme.text} />
            </Pressable>
            <ThemedText type="h3">New Project</ThemedText>
            <View style={{ width: 24 }} />
          </View>

          <ScrollView style={styles.modalContent}>
            <View style={styles.inputGroup}>
              <ThemedText type="small" style={styles.inputLabel}>
                Title
              </ThemedText>
              <TextInput
                style={[
                  styles.textInput,
                  {
                    backgroundColor: theme.backgroundSecondary,
                    color: theme.text,
                    borderColor: theme.border,
                  },
                ]}
                placeholder="Enter your novel title"
                placeholderTextColor={theme.textTertiary}
                value={newProjectTitle}
                onChangeText={setNewProjectTitle}
              />
            </View>

            <View style={styles.inputGroup}>
              <ThemedText type="small" style={styles.inputLabel}>
                Genre
              </ThemedText>
              <View style={styles.genreGrid}>
                {GENRES.map((genre) => (
                  <Pressable
                    key={genre}
                    style={[
                      styles.genreOption,
                      {
                        backgroundColor:
                          newProjectGenre === genre
                            ? theme.primary
                            : theme.backgroundSecondary,
                        borderColor:
                          newProjectGenre === genre
                            ? theme.primary
                            : theme.border,
                      },
                    ]}
                    onPress={() => setNewProjectGenre(genre)}
                  >
                    <ThemedText
                      type="small"
                      style={{
                        color:
                          newProjectGenre === genre ? "#FFFFFF" : theme.text,
                      }}
                    >
                      {genre}
                    </ThemedText>
                  </Pressable>
                ))}
              </View>
            </View>

            <View style={styles.inputGroup}>
              <ThemedText type="small" style={styles.inputLabel}>
                Description (optional)
              </ThemedText>
              <TextInput
                style={[
                  styles.textInput,
                  styles.textArea,
                  {
                    backgroundColor: theme.backgroundSecondary,
                    color: theme.text,
                    borderColor: theme.border,
                  },
                ]}
                placeholder="A brief description of your novel"
                placeholderTextColor={theme.textTertiary}
                value={newProjectDescription}
                onChangeText={setNewProjectDescription}
                multiline
                numberOfLines={3}
              />
            </View>

            <View style={styles.inputGroup}>
              <ThemedText type="small" style={styles.inputLabel}>
                Target Word Count
              </ThemedText>
              <TextInput
                style={[
                  styles.textInput,
                  {
                    backgroundColor: theme.backgroundSecondary,
                    color: theme.text,
                    borderColor: theme.border,
                  },
                ]}
                placeholder="50000"
                placeholderTextColor={theme.textTertiary}
                value={newProjectTarget}
                onChangeText={setNewProjectTarget}
                keyboardType="number-pad"
              />
            </View>

            <Button
              onPress={handleCreateProject}
              disabled={isSaving || !newProjectTitle.trim()}
              style={{ marginTop: Spacing.xl, marginBottom: Spacing["3xl"] }}
            >
              {isSaving ? "Creating..." : "Create Project"}
            </Button>
          </ScrollView>
        </ThemedView>
      </Modal>

      <Modal
        visible={showSettings}
        animationType="slide"
        presentationStyle="pageSheet"
        onRequestClose={() => setShowSettings(false)}
      >
        <ThemedView style={styles.modalContainer}>
          <View style={styles.modalHeader}>
            <Pressable onPress={() => setShowSettings(false)}>
              <Feather name="x" size={24} color={theme.text} />
            </Pressable>
            <ThemedText type="h3">Settings</ThemedText>
            <View style={{ width: 24 }} />
          </View>

          <View style={styles.modalContent}>
            <View
              style={[
                styles.profileSection,
                { backgroundColor: theme.backgroundDefault },
              ]}
            >
              <View
                style={[styles.profileAvatar, { backgroundColor: theme.primary }]}
              >
                <ThemedText type="h2" style={{ color: "#FFFFFF" }}>
                  {user?.name?.charAt(0).toUpperCase() || "G"}
                </ThemedText>
              </View>
              <View style={styles.profileInfo}>
                <ThemedText type="h4">{user?.name || "Guest Writer"}</ThemedText>
                <ThemedText type="small" style={{ color: theme.textSecondary }}>
                  {user?.email || "guest@novelcraft.app"}
                </ThemedText>
              </View>
            </View>

            <View style={styles.settingsSection}>
              <ThemedText type="h4" style={styles.settingsSectionTitle}>
                Account
              </ThemedText>

              <Pressable
                style={[
                  styles.settingsItem,
                  { backgroundColor: theme.backgroundDefault },
                ]}
                onPress={handleSignOut}
              >
                <View style={styles.settingsItemLeft}>
                  <View
                    style={[
                      styles.settingsIcon,
                      { backgroundColor: theme.error + "20" },
                    ]}
                  >
                    <Feather name="log-out" size={18} color={theme.error} />
                  </View>
                  <ThemedText type="body" style={{ color: theme.error }}>
                    Sign Out
                  </ThemedText>
                </View>
                <Feather name="chevron-right" size={18} color={theme.textTertiary} />
              </Pressable>
            </View>

            <View style={styles.settingsSection}>
              <ThemedText type="h4" style={styles.settingsSectionTitle}>
                About
              </ThemedText>

              <View
                style={[
                  styles.settingsItem,
                  { backgroundColor: theme.backgroundDefault },
                ]}
              >
                <View style={styles.settingsItemLeft}>
                  <View
                    style={[
                      styles.settingsIcon,
                      { backgroundColor: theme.primary + "20" },
                    ]}
                  >
                    <Feather name="info" size={18} color={theme.primary} />
                  </View>
                  <ThemedText type="body">Version</ThemedText>
                </View>
                <ThemedText type="small" style={{ color: theme.textTertiary }}>
                  1.0.0
                </ThemedText>
              </View>
            </View>
          </View>
        </ThemedView>
      </Modal>

      <Modal
        visible={showExportModal}
        animationType="fade"
        transparent
        onRequestClose={() => {
          setShowExportModal(false);
          setExportingProject(null);
        }}
      >
        <View style={styles.exportModalOverlay}>
          <View
            style={[
              styles.exportModalContent,
              { backgroundColor: theme.backgroundRoot },
            ]}
          >
            <ThemedText type="h3" style={styles.exportTitle}>
              Export "{exportingProject?.title}"
            </ThemedText>
            <ThemedText
              type="small"
              style={{ color: theme.textSecondary, marginBottom: Spacing.xl }}
            >
              Choose a format to export your novel
            </ThemedText>

            <Pressable
              style={[
                styles.exportOption,
                { backgroundColor: theme.backgroundDefault },
              ]}
              onPress={() => handleExport("html")}
              disabled={isExporting}
            >
              <View style={styles.exportOptionLeft}>
                <View
                  style={[
                    styles.exportIcon,
                    { backgroundColor: theme.primary + "20" },
                  ]}
                >
                  <Feather name="file" size={20} color={theme.primary} />
                </View>
                <View>
                  <ThemedText type="h4">HTML Document</ThemedText>
                  <ThemedText type="small" style={{ color: theme.textSecondary }}>
                    Beautiful formatted document, ready for print
                  </ThemedText>
                </View>
              </View>
            </Pressable>

            <Pressable
              style={[
                styles.exportOption,
                { backgroundColor: theme.backgroundDefault },
              ]}
              onPress={() => handleExport("txt")}
              disabled={isExporting}
            >
              <View style={styles.exportOptionLeft}>
                <View
                  style={[
                    styles.exportIcon,
                    { backgroundColor: theme.success + "20" },
                  ]}
                >
                  <Feather name="file-text" size={20} color={theme.success} />
                </View>
                <View>
                  <ThemedText type="h4">Plain Text</ThemedText>
                  <ThemedText type="small" style={{ color: theme.textSecondary }}>
                    Simple text file for easy editing
                  </ThemedText>
                </View>
              </View>
            </Pressable>

            {isExporting ? (
              <View style={styles.exportLoading}>
                <ActivityIndicator size="small" color={theme.primary} />
                <ThemedText type="small" style={{ color: theme.textSecondary }}>
                  Preparing export...
                </ThemedText>
              </View>
            ) : null}

            <Pressable
              style={styles.exportCancel}
              onPress={() => {
                setShowExportModal(false);
                setExportingProject(null);
              }}
            >
              <ThemedText type="body" style={{ color: theme.textSecondary }}>
                Cancel
              </ThemedText>
            </Pressable>
          </View>
        </View>
      </Modal>
    </ThemedView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  header: {
    paddingHorizontal: Spacing.xl,
    paddingBottom: Spacing.lg,
  },
  headerContent: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  logoContainer: {
    flexDirection: "row",
    alignItems: "center",
    gap: Spacing.md,
  },
  logoIcon: {
    width: 36,
    height: 36,
    borderRadius: BorderRadius.sm,
    justifyContent: "center",
    alignItems: "center",
  },
  settingsButton: {
    width: 40,
    height: 40,
    borderRadius: BorderRadius.full,
    justifyContent: "center",
    alignItems: "center",
  },
  scrollContent: {
    paddingHorizontal: Spacing.xl,
  },
  statsCard: {
    flexDirection: "row",
    borderRadius: BorderRadius.lg,
    padding: Spacing.xl,
    marginBottom: Spacing.xl,
  },
  statItem: {
    flex: 1,
    alignItems: "center",
  },
  statDivider: {
    width: 1,
    marginHorizontal: Spacing.lg,
  },
  currentProjectSection: {
    marginBottom: Spacing.xl,
  },
  projectsSection: {
    marginBottom: Spacing.xl,
  },
  sectionTitle: {
    marginBottom: Spacing.md,
  },
  projectCard: {
    borderRadius: BorderRadius.lg,
    padding: Spacing.lg,
    marginBottom: Spacing.md,
  },
  projectCardHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: Spacing.md,
  },
  genreIconContainer: {
    width: 40,
    height: 40,
    borderRadius: BorderRadius.sm,
    justifyContent: "center",
    alignItems: "center",
  },
  projectCardActions: {
    flexDirection: "row",
    alignItems: "center",
    gap: Spacing.sm,
  },
  exportIconButton: {
    width: 28,
    height: 28,
    borderRadius: BorderRadius.full,
    justifyContent: "center",
    alignItems: "center",
  },
  genreTag: {
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.xs,
    borderRadius: BorderRadius.full,
  },
  projectTitle: {
    marginBottom: Spacing.sm,
  },
  projectStats: {
    flexDirection: "row",
    justifyContent: "space-between",
  },
  progressContainer: {
    flexDirection: "row",
    alignItems: "center",
    marginTop: Spacing.md,
    gap: Spacing.sm,
  },
  progressBar: {
    flex: 1,
    height: 4,
    borderRadius: 2,
    overflow: "hidden",
  },
  progressFill: {
    height: "100%",
    borderRadius: 2,
  },
  emptyState: {
    alignItems: "center",
    padding: Spacing["3xl"],
    borderRadius: BorderRadius.lg,
  },
  fab: {
    position: "absolute",
    right: Spacing.xl,
    width: 56,
    height: 56,
    borderRadius: 28,
    justifyContent: "center",
    alignItems: "center",
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 4,
  },
  modalContainer: {
    flex: 1,
  },
  modalHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingHorizontal: Spacing.xl,
    paddingTop: Spacing.xl,
    paddingBottom: Spacing.lg,
  },
  modalContent: {
    flex: 1,
    paddingHorizontal: Spacing.xl,
  },
  inputGroup: {
    marginBottom: Spacing.xl,
  },
  inputLabel: {
    marginBottom: Spacing.sm,
    fontWeight: "500",
  },
  textInput: {
    height: Spacing.inputHeight,
    borderRadius: BorderRadius.sm,
    paddingHorizontal: Spacing.lg,
    fontSize: 16,
    borderWidth: 1,
  },
  textArea: {
    height: 100,
    paddingTop: Spacing.md,
    textAlignVertical: "top",
  },
  genreGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: Spacing.sm,
  },
  genreOption: {
    paddingHorizontal: Spacing.lg,
    paddingVertical: Spacing.sm,
    borderRadius: BorderRadius.full,
    borderWidth: 1,
  },
  profileSection: {
    flexDirection: "row",
    alignItems: "center",
    padding: Spacing.xl,
    borderRadius: BorderRadius.lg,
    marginBottom: Spacing.xl,
  },
  profileAvatar: {
    width: 56,
    height: 56,
    borderRadius: 28,
    justifyContent: "center",
    alignItems: "center",
    marginRight: Spacing.lg,
  },
  profileInfo: {
    flex: 1,
  },
  settingsSection: {
    marginBottom: Spacing.xl,
  },
  settingsSectionTitle: {
    marginBottom: Spacing.md,
  },
  settingsItem: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    padding: Spacing.lg,
    borderRadius: BorderRadius.md,
    marginBottom: Spacing.sm,
  },
  settingsItemLeft: {
    flexDirection: "row",
    alignItems: "center",
    gap: Spacing.md,
  },
  settingsIcon: {
    width: 36,
    height: 36,
    borderRadius: BorderRadius.sm,
    justifyContent: "center",
    alignItems: "center",
  },
  exportModalOverlay: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.5)",
    justifyContent: "center",
    alignItems: "center",
    padding: Spacing.xl,
  },
  exportModalContent: {
    width: "100%",
    borderRadius: BorderRadius.lg,
    padding: Spacing.xl,
  },
  exportTitle: {
    marginBottom: Spacing.sm,
  },
  exportOption: {
    padding: Spacing.lg,
    borderRadius: BorderRadius.md,
    marginBottom: Spacing.md,
  },
  exportOptionLeft: {
    flexDirection: "row",
    alignItems: "center",
    gap: Spacing.md,
  },
  exportIcon: {
    width: 44,
    height: 44,
    borderRadius: BorderRadius.sm,
    justifyContent: "center",
    alignItems: "center",
  },
  exportLoading: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: Spacing.sm,
    marginTop: Spacing.md,
  },
  exportCancel: {
    alignItems: "center",
    paddingVertical: Spacing.lg,
    marginTop: Spacing.md,
  },
});
