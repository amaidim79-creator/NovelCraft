import React, { useState, useCallback } from "react";
import {
  View,
  StyleSheet,
  Pressable,
  Modal,
  TextInput,
  Alert,
  ScrollView,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useBottomTabBarHeight } from "@react-navigation/bottom-tabs";
import { Feather } from "@expo/vector-icons";
import Animated, {
  useAnimatedStyle,
  useSharedValue,
  withSpring,
} from "react-native-reanimated";

import { ThemedText } from "@/components/ThemedText";
import { ThemedView } from "@/components/ThemedView";
import { ScreenScrollView } from "@/components/ScreenScrollView";
import { Button } from "@/components/Button";
import { useTheme } from "@/hooks/useTheme";
import { useApp } from "@/context/AppContext";
import { Spacing, BorderRadius } from "@/constants/theme";
import { PlotPoint } from "@/utils/storage";

const PLOT_TYPES = [
  { id: "setup", label: "Setup", color: "#3B82F6" },
  { id: "rising", label: "Rising Action", color: "#10B981" },
  { id: "climax", label: "Climax", color: "#EF4444" },
  { id: "falling", label: "Falling Action", color: "#F59E0B" },
  { id: "resolution", label: "Resolution", color: "#8B5CF6" },
];

const TEMPLATES = [
  {
    name: "Three-Act Structure",
    points: [
      { title: "Opening Scene", type: "setup", act: 1 },
      { title: "Inciting Incident", type: "setup", act: 1 },
      { title: "First Plot Point", type: "rising", act: 1 },
      { title: "Rising Action", type: "rising", act: 2 },
      { title: "Midpoint", type: "climax", act: 2 },
      { title: "Second Plot Point", type: "falling", act: 2 },
      { title: "Climax", type: "climax", act: 3 },
      { title: "Resolution", type: "resolution", act: 3 },
    ],
  },
  {
    name: "Hero's Journey",
    points: [
      { title: "Ordinary World", type: "setup", act: 1 },
      { title: "Call to Adventure", type: "setup", act: 1 },
      { title: "Refusal of the Call", type: "setup", act: 1 },
      { title: "Meeting the Mentor", type: "rising", act: 1 },
      { title: "Crossing the Threshold", type: "rising", act: 2 },
      { title: "Tests, Allies, Enemies", type: "rising", act: 2 },
      { title: "Approach to Inmost Cave", type: "rising", act: 2 },
      { title: "Ordeal", type: "climax", act: 2 },
      { title: "Reward", type: "falling", act: 2 },
      { title: "The Road Back", type: "falling", act: 3 },
      { title: "Resurrection", type: "climax", act: 3 },
      { title: "Return with Elixir", type: "resolution", act: 3 },
    ],
  },
];

const AnimatedPressable = Animated.createAnimatedComponent(Pressable);

function PlotPointCard({
  plotPoint,
  onPress,
  onLongPress,
  theme,
}: {
  plotPoint: PlotPoint;
  onPress: () => void;
  onLongPress: () => void;
  theme: any;
}) {
  const scale = useSharedValue(1);
  const plotType = PLOT_TYPES.find((t) => t.id === plotPoint.type);

  const animatedStyle = useAnimatedStyle(() => ({
    transform: [{ scale: scale.value }],
  }));

  return (
    <AnimatedPressable
      onPress={onPress}
      onLongPress={onLongPress}
      onPressIn={() => {
        scale.value = withSpring(0.98, { damping: 15, stiffness: 150 });
      }}
      onPressOut={() => {
        scale.value = withSpring(1, { damping: 15, stiffness: 150 });
      }}
      style={[
        styles.plotCard,
        { backgroundColor: theme.backgroundDefault },
        animatedStyle,
      ]}
    >
      <View style={styles.plotCardLeft}>
        <View
          style={[
            styles.plotTypeIndicator,
            { backgroundColor: plotType?.color || theme.primary },
          ]}
        />
        <View style={styles.plotCardContent}>
          <ThemedText type="h4" numberOfLines={1}>
            {plotPoint.title}
          </ThemedText>
          {plotPoint.description ? (
            <ThemedText
              type="small"
              numberOfLines={2}
              style={{ color: theme.textSecondary, marginTop: Spacing.xs }}
            >
              {plotPoint.description}
            </ThemedText>
          ) : null}
        </View>
      </View>
      <View style={[styles.plotTypeTag, { backgroundColor: (plotType?.color || theme.primary) + "20" }]}>
        <ThemedText type="small" style={{ color: plotType?.color || theme.primary }}>
          {plotType?.label || "Plot Point"}
        </ThemedText>
      </View>
    </AnimatedPressable>
  );
}

export default function PlotScreen() {
  const { theme, isDark } = useTheme();
  const insets = useSafeAreaInsets();
  const tabBarHeight = useBottomTabBarHeight();
  const {
    currentProject,
    getProjectPlotPoints,
    addPlotPoint,
    updatePlotPoint,
    deletePlotPoint,
    getProjectCharacters,
  } = useApp();

  const [showNewPlotPoint, setShowNewPlotPoint] = useState(false);
  const [showTemplates, setShowTemplates] = useState(false);
  const [editingPlotPoint, setEditingPlotPoint] = useState<PlotPoint | null>(null);
  const [plotTitle, setPlotTitle] = useState("");
  const [plotDescription, setPlotDescription] = useState("");
  const [plotAct, setPlotAct] = useState<1 | 2 | 3>(1);
  const [plotType, setPlotType] = useState<PlotPoint["type"]>("setup");
  const [isSaving, setIsSaving] = useState(false);

  const plotPoints = currentProject
    ? getProjectPlotPoints(currentProject.id)
    : [];
  const characters = currentProject
    ? getProjectCharacters(currentProject.id)
    : [];

  const actPlotPoints = {
    1: plotPoints.filter((p) => p.act === 1),
    2: plotPoints.filter((p) => p.act === 2),
    3: plotPoints.filter((p) => p.act === 3),
  };

  const handleSavePlotPoint = async () => {
    if (!currentProject || !plotTitle.trim()) {
      Alert.alert("Error", "Please enter a title");
      return;
    }

    setIsSaving(true);
    try {
      if (editingPlotPoint) {
        await updatePlotPoint(editingPlotPoint.id, {
          title: plotTitle.trim(),
          description: plotDescription.trim(),
          act: plotAct,
          type: plotType,
        });
      } else {
        const maxOrder = Math.max(0, ...plotPoints.map((p) => p.order));
        await addPlotPoint({
          projectId: currentProject.id,
          title: plotTitle.trim(),
          description: plotDescription.trim(),
          act: plotAct,
          order: maxOrder + 1,
          type: plotType,
          characters: [],
        });
      }
      resetForm();
    } catch (error) {
      Alert.alert("Error", "Failed to save plot point");
    } finally {
      setIsSaving(false);
    }
  };

  const handleDeletePlotPoint = (plotPoint: PlotPoint) => {
    Alert.alert(
      "Delete Plot Point",
      `Are you sure you want to delete "${plotPoint.title}"?`,
      [
        { text: "Cancel", style: "cancel" },
        {
          text: "Delete",
          style: "destructive",
          onPress: () => deletePlotPoint(plotPoint.id),
        },
      ]
    );
  };

  const handleEditPlotPoint = (plotPoint: PlotPoint) => {
    setEditingPlotPoint(plotPoint);
    setPlotTitle(plotPoint.title);
    setPlotDescription(plotPoint.description);
    setPlotAct(plotPoint.act);
    setPlotType(plotPoint.type);
    setShowNewPlotPoint(true);
  };

  const handleApplyTemplate = async (template: typeof TEMPLATES[0]) => {
    if (!currentProject) return;

    setIsSaving(true);
    try {
      for (let i = 0; i < template.points.length; i++) {
        const point = template.points[i];
        await addPlotPoint({
          projectId: currentProject.id,
          title: point.title,
          description: "",
          act: point.act as 1 | 2 | 3,
          order: i + 1,
          type: point.type as PlotPoint["type"],
          characters: [],
        });
      }
      setShowTemplates(false);
    } catch (error) {
      Alert.alert("Error", "Failed to apply template");
    } finally {
      setIsSaving(false);
    }
  };

  const resetForm = () => {
    setShowNewPlotPoint(false);
    setEditingPlotPoint(null);
    setPlotTitle("");
    setPlotDescription("");
    setPlotAct(1);
    setPlotType("setup");
  };

  if (!currentProject) {
    return (
      <ThemedView style={styles.container}>
        <View style={[styles.header, { paddingTop: insets.top + Spacing.lg }]}>
          <ThemedText type="h1">Plot Designer</ThemedText>
        </View>
        <View style={styles.emptyContainer}>
          <Feather name="git-branch" size={64} color={theme.textTertiary} />
          <ThemedText
            type="h3"
            style={{ color: theme.textSecondary, marginTop: Spacing.xl }}
          >
            No Project Selected
          </ThemedText>
          <ThemedText
            type="body"
            style={{
              color: theme.textTertiary,
              textAlign: "center",
              marginTop: Spacing.sm,
              paddingHorizontal: Spacing["3xl"],
            }}
          >
            Select or create a project from the Projects tab to start designing
            your plot
          </ThemedText>
        </View>
      </ThemedView>
    );
  }

  return (
    <ThemedView style={styles.container}>
      <View style={[styles.header, { paddingTop: insets.top + Spacing.lg }]}>
        <View style={styles.headerTop}>
          <ThemedText type="h1">Plot Designer</ThemedText>
          <View style={styles.headerActions}>
            <Pressable
              style={[styles.headerButton, { backgroundColor: theme.backgroundDefault }]}
              onPress={() => setShowTemplates(true)}
            >
              <Feather name="layers" size={20} color={theme.text} />
            </Pressable>
            <Pressable
              style={[styles.headerButton, { backgroundColor: theme.primary }]}
              onPress={() => setShowNewPlotPoint(true)}
            >
              <Feather name="plus" size={20} color="#FFFFFF" />
            </Pressable>
          </View>
        </View>
        <ThemedText type="small" style={{ color: theme.textSecondary }}>
          {currentProject.title}
        </ThemedText>
      </View>

      <ScreenScrollView
        contentContainerStyle={[
          styles.scrollContent,
          { paddingBottom: tabBarHeight + Spacing.xl },
        ]}
      >
        {plotPoints.length === 0 ? (
          <View
            style={[
              styles.emptyState,
              { backgroundColor: theme.backgroundDefault },
            ]}
          >
            <Feather name="map" size={48} color={theme.textTertiary} />
            <ThemedText
              type="body"
              style={{ color: theme.textSecondary, marginTop: Spacing.lg }}
            >
              No plot points yet
            </ThemedText>
            <ThemedText
              type="small"
              style={{
                color: theme.textTertiary,
                textAlign: "center",
                marginTop: Spacing.sm,
              }}
            >
              Add plot points or use a template to structure your story
            </ThemedText>
            <Pressable
              style={[
                styles.templateButton,
                { borderColor: theme.primary },
              ]}
              onPress={() => setShowTemplates(true)}
            >
              <Feather name="layers" size={16} color={theme.primary} />
              <ThemedText type="body" style={{ color: theme.primary }}>
                Use a Template
              </ThemedText>
            </Pressable>
          </View>
        ) : (
          [1, 2, 3].map((act) => (
            <View key={act} style={styles.actSection}>
              <View style={styles.actHeader}>
                <View
                  style={[
                    styles.actBadge,
                    { backgroundColor: theme.primary + "20" },
                  ]}
                >
                  <ThemedText type="h4" style={{ color: theme.primary }}>
                    Act {act}
                  </ThemedText>
                </View>
                <ThemedText type="small" style={{ color: theme.textTertiary }}>
                  {actPlotPoints[act as 1 | 2 | 3].length} points
                </ThemedText>
              </View>
              {actPlotPoints[act as 1 | 2 | 3].map((plotPoint) => (
                <PlotPointCard
                  key={plotPoint.id}
                  plotPoint={plotPoint}
                  onPress={() => handleEditPlotPoint(plotPoint)}
                  onLongPress={() => handleDeletePlotPoint(plotPoint)}
                  theme={theme}
                />
              ))}
              {actPlotPoints[act as 1 | 2 | 3].length === 0 ? (
                <Pressable
                  style={[
                    styles.addPlotPointButton,
                    { borderColor: theme.border },
                  ]}
                  onPress={() => {
                    setPlotAct(act as 1 | 2 | 3);
                    setShowNewPlotPoint(true);
                  }}
                >
                  <Feather name="plus" size={16} color={theme.textTertiary} />
                  <ThemedText type="small" style={{ color: theme.textTertiary }}>
                    Add plot point
                  </ThemedText>
                </Pressable>
              ) : null}
            </View>
          ))
        )}
      </ScreenScrollView>

      <Modal
        visible={showNewPlotPoint}
        animationType="slide"
        presentationStyle="pageSheet"
        onRequestClose={resetForm}
      >
        <ThemedView style={styles.modalContainer}>
          <View style={styles.modalHeader}>
            <Pressable onPress={resetForm}>
              <Feather name="x" size={24} color={theme.text} />
            </Pressable>
            <ThemedText type="h3">
              {editingPlotPoint ? "Edit Plot Point" : "New Plot Point"}
            </ThemedText>
            <View style={{ width: 24 }} />
          </View>

          <ScrollView style={styles.modalContent}>
            <View style={styles.inputGroup}>
              <ThemedText type="small" style={styles.inputLabel}>
                Title
              </ThemedText>
              <TextInput
                style={[
                  styles.textInput,
                  {
                    backgroundColor: theme.backgroundSecondary,
                    color: theme.text,
                    borderColor: theme.border,
                  },
                ]}
                placeholder="Enter plot point title"
                placeholderTextColor={theme.textTertiary}
                value={plotTitle}
                onChangeText={setPlotTitle}
              />
            </View>

            <View style={styles.inputGroup}>
              <ThemedText type="small" style={styles.inputLabel}>
                Description
              </ThemedText>
              <TextInput
                style={[
                  styles.textInput,
                  styles.textArea,
                  {
                    backgroundColor: theme.backgroundSecondary,
                    color: theme.text,
                    borderColor: theme.border,
                  },
                ]}
                placeholder="Describe what happens"
                placeholderTextColor={theme.textTertiary}
                value={plotDescription}
                onChangeText={setPlotDescription}
                multiline
                numberOfLines={4}
              />
            </View>

            <View style={styles.inputGroup}>
              <ThemedText type="small" style={styles.inputLabel}>
                Act
              </ThemedText>
              <View style={styles.actSelector}>
                {[1, 2, 3].map((act) => (
                  <Pressable
                    key={act}
                    style={[
                      styles.actOption,
                      {
                        backgroundColor:
                          plotAct === act
                            ? theme.primary
                            : theme.backgroundSecondary,
                        borderColor:
                          plotAct === act ? theme.primary : theme.border,
                      },
                    ]}
                    onPress={() => setPlotAct(act as 1 | 2 | 3)}
                  >
                    <ThemedText
                      type="body"
                      style={{
                        color: plotAct === act ? "#FFFFFF" : theme.text,
                      }}
                    >
                      Act {act}
                    </ThemedText>
                  </Pressable>
                ))}
              </View>
            </View>

            <View style={styles.inputGroup}>
              <ThemedText type="small" style={styles.inputLabel}>
                Type
              </ThemedText>
              <View style={styles.typeSelector}>
                {PLOT_TYPES.map((type) => (
                  <Pressable
                    key={type.id}
                    style={[
                      styles.typeOption,
                      {
                        backgroundColor:
                          plotType === type.id
                            ? type.color
                            : theme.backgroundSecondary,
                        borderColor:
                          plotType === type.id ? type.color : theme.border,
                      },
                    ]}
                    onPress={() => setPlotType(type.id as PlotPoint["type"])}
                  >
                    <ThemedText
                      type="small"
                      style={{
                        color: plotType === type.id ? "#FFFFFF" : theme.text,
                      }}
                    >
                      {type.label}
                    </ThemedText>
                  </Pressable>
                ))}
              </View>
            </View>

            <Button
              onPress={handleSavePlotPoint}
              disabled={isSaving || !plotTitle.trim()}
              style={{ marginTop: Spacing.xl, marginBottom: Spacing["3xl"] }}
            >
              {isSaving ? "Saving..." : editingPlotPoint ? "Update" : "Add Plot Point"}
            </Button>
          </ScrollView>
        </ThemedView>
      </Modal>

      <Modal
        visible={showTemplates}
        animationType="slide"
        presentationStyle="pageSheet"
        onRequestClose={() => setShowTemplates(false)}
      >
        <ThemedView style={styles.modalContainer}>
          <View style={styles.modalHeader}>
            <Pressable onPress={() => setShowTemplates(false)}>
              <Feather name="x" size={24} color={theme.text} />
            </Pressable>
            <ThemedText type="h3">Plot Templates</ThemedText>
            <View style={{ width: 24 }} />
          </View>

          <ScrollView style={styles.modalContent}>
            {TEMPLATES.map((template, index) => (
              <Pressable
                key={index}
                style={[
                  styles.templateCard,
                  { backgroundColor: theme.backgroundDefault },
                ]}
                onPress={() => handleApplyTemplate(template)}
              >
                <ThemedText type="h3" style={{ marginBottom: Spacing.sm }}>
                  {template.name}
                </ThemedText>
                <ThemedText type="small" style={{ color: theme.textSecondary }}>
                  {template.points.length} plot points
                </ThemedText>
                <View style={styles.templatePreview}>
                  {template.points.slice(0, 4).map((point, i) => (
                    <View
                      key={i}
                      style={[
                        styles.previewDot,
                        {
                          backgroundColor:
                            PLOT_TYPES.find((t) => t.id === point.type)?.color ||
                            theme.primary,
                        },
                      ]}
                    />
                  ))}
                  {template.points.length > 4 ? (
                    <ThemedText type="small" style={{ color: theme.textTertiary }}>
                      +{template.points.length - 4} more
                    </ThemedText>
                  ) : null}
                </View>
              </Pressable>
            ))}
          </ScrollView>
        </ThemedView>
      </Modal>
    </ThemedView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    paddingHorizontal: Spacing.xl,
    paddingBottom: Spacing.md,
  },
  headerTop: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  headerActions: {
    flexDirection: "row",
    gap: Spacing.sm,
  },
  headerButton: {
    width: 40,
    height: 40,
    borderRadius: BorderRadius.full,
    justifyContent: "center",
    alignItems: "center",
  },
  emptyContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    paddingBottom: 100,
  },
  scrollContent: {
    paddingHorizontal: Spacing.xl,
  },
  emptyState: {
    alignItems: "center",
    padding: Spacing["3xl"],
    borderRadius: BorderRadius.lg,
  },
  templateButton: {
    flexDirection: "row",
    alignItems: "center",
    gap: Spacing.sm,
    paddingHorizontal: Spacing.xl,
    paddingVertical: Spacing.md,
    borderRadius: BorderRadius.full,
    borderWidth: 1,
    marginTop: Spacing.xl,
  },
  actSection: {
    marginBottom: Spacing.xl,
  },
  actHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: Spacing.md,
  },
  actBadge: {
    paddingHorizontal: Spacing.lg,
    paddingVertical: Spacing.xs,
    borderRadius: BorderRadius.sm,
  },
  plotCard: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    padding: Spacing.lg,
    borderRadius: BorderRadius.md,
    marginBottom: Spacing.sm,
  },
  plotCardLeft: {
    flexDirection: "row",
    alignItems: "center",
    flex: 1,
    marginRight: Spacing.md,
  },
  plotTypeIndicator: {
    width: 4,
    height: 40,
    borderRadius: 2,
    marginRight: Spacing.md,
  },
  plotCardContent: {
    flex: 1,
  },
  plotTypeTag: {
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.xs,
    borderRadius: BorderRadius.full,
  },
  addPlotPointButton: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: Spacing.sm,
    padding: Spacing.lg,
    borderRadius: BorderRadius.md,
    borderWidth: 1,
    borderStyle: "dashed",
  },
  modalContainer: {
    flex: 1,
  },
  modalHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingHorizontal: Spacing.xl,
    paddingTop: Spacing.xl,
    paddingBottom: Spacing.lg,
  },
  modalContent: {
    flex: 1,
    paddingHorizontal: Spacing.xl,
  },
  inputGroup: {
    marginBottom: Spacing.xl,
  },
  inputLabel: {
    marginBottom: Spacing.sm,
    fontWeight: "500",
  },
  textInput: {
    height: Spacing.inputHeight,
    borderRadius: BorderRadius.sm,
    paddingHorizontal: Spacing.lg,
    fontSize: 16,
    borderWidth: 1,
  },
  textArea: {
    height: 120,
    paddingTop: Spacing.md,
    textAlignVertical: "top",
  },
  actSelector: {
    flexDirection: "row",
    gap: Spacing.sm,
  },
  actOption: {
    flex: 1,
    alignItems: "center",
    paddingVertical: Spacing.md,
    borderRadius: BorderRadius.sm,
    borderWidth: 1,
  },
  typeSelector: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: Spacing.sm,
  },
  typeOption: {
    paddingHorizontal: Spacing.lg,
    paddingVertical: Spacing.sm,
    borderRadius: BorderRadius.full,
    borderWidth: 1,
  },
  templateCard: {
    padding: Spacing.xl,
    borderRadius: BorderRadius.lg,
    marginBottom: Spacing.md,
  },
  templatePreview: {
    flexDirection: "row",
    alignItems: "center",
    gap: Spacing.sm,
    marginTop: Spacing.md,
  },
  previewDot: {
    width: 12,
    height: 12,
    borderRadius: 6,
  },
});
