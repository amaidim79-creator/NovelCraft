import React, { useState, useCallback } from "react";
import {
  View,
  StyleSheet,
  Pressable,
  Modal,
  TextInput,
  Alert,
  ScrollView,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useBottomTabBarHeight } from "@react-navigation/bottom-tabs";
import { Feather } from "@expo/vector-icons";
import Animated, {
  useAnimatedStyle,
  useSharedValue,
  withSpring,
} from "react-native-reanimated";

import { ThemedText } from "@/components/ThemedText";
import { ThemedView } from "@/components/ThemedView";
import { ScreenScrollView } from "@/components/ScreenScrollView";
import { ScreenKeyboardAwareScrollView } from "@/components/ScreenKeyboardAwareScrollView";
import { Button } from "@/components/Button";
import { useTheme } from "@/hooks/useTheme";
import { useApp } from "@/context/AppContext";
import { Spacing, BorderRadius } from "@/constants/theme";
import { Character } from "@/utils/storage";

const ROLES = [
  { id: "protagonist", label: "Protagonist", color: "#10B981" },
  { id: "antagonist", label: "Antagonist", color: "#EF4444" },
  { id: "supporting", label: "Supporting", color: "#3B82F6" },
  { id: "minor", label: "Minor", color: "#8B5CF6" },
];

const AVATAR_COLORS = [
  "#6366F1",
  "#EC4899",
  "#10B981",
  "#F59E0B",
  "#EF4444",
  "#3B82F6",
  "#8B5CF6",
  "#14B8A6",
];

const AnimatedPressable = Animated.createAnimatedComponent(Pressable);

function CharacterCard({
  character,
  onPress,
  onLongPress,
  theme,
}: {
  character: Character;
  onPress: () => void;
  onLongPress: () => void;
  theme: any;
}) {
  const scale = useSharedValue(1);
  const role = ROLES.find((r) => r.id === character.role);

  const animatedStyle = useAnimatedStyle(() => ({
    transform: [{ scale: scale.value }],
  }));

  return (
    <AnimatedPressable
      onPress={onPress}
      onLongPress={onLongPress}
      onPressIn={() => {
        scale.value = withSpring(0.98, { damping: 15, stiffness: 150 });
      }}
      onPressOut={() => {
        scale.value = withSpring(1, { damping: 15, stiffness: 150 });
      }}
      style={[
        styles.characterCard,
        { backgroundColor: theme.backgroundDefault },
        animatedStyle,
      ]}
    >
      <View
        style={[
          styles.avatar,
          { backgroundColor: character.avatarColor || theme.primary },
        ]}
      >
        <ThemedText type="h3" style={{ color: "#FFFFFF" }}>
          {character.name.charAt(0).toUpperCase()}
        </ThemedText>
      </View>
      <View style={styles.characterInfo}>
        <ThemedText type="h4" numberOfLines={1}>
          {character.name}
        </ThemedText>
        <View style={styles.characterMeta}>
          <View
            style={[
              styles.roleTag,
              { backgroundColor: (role?.color || theme.primary) + "20" },
            ]}
          >
            <ThemedText
              type="small"
              style={{ color: role?.color || theme.primary }}
            >
              {role?.label || "Character"}
            </ThemedText>
          </View>
          {character.age ? (
            <ThemedText type="small" style={{ color: theme.textTertiary }}>
              Age: {character.age}
            </ThemedText>
          ) : null}
        </View>
      </View>
      <Feather name="chevron-right" size={16} color={theme.textTertiary} />
    </AnimatedPressable>
  );
}

export default function CharactersScreen() {
  const { theme, isDark } = useTheme();
  const insets = useSafeAreaInsets();
  const tabBarHeight = useBottomTabBarHeight();
  const {
    currentProject,
    getProjectCharacters,
    addCharacter,
    updateCharacter,
    deleteCharacter,
  } = useApp();

  const [showCharacterModal, setShowCharacterModal] = useState(false);
  const [editingCharacter, setEditingCharacter] = useState<Character | null>(null);
  const [searchQuery, setSearchQuery] = useState("");

  const [name, setName] = useState("");
  const [role, setRole] = useState<Character["role"]>("supporting");
  const [age, setAge] = useState("");
  const [appearance, setAppearance] = useState("");
  const [personality, setPersonality] = useState("");
  const [backstory, setBackstory] = useState("");
  const [goals, setGoals] = useState("");
  const [relationships, setRelationships] = useState("");
  const [notes, setNotes] = useState("");
  const [avatarColor, setAvatarColor] = useState(AVATAR_COLORS[0]);
  const [isSaving, setIsSaving] = useState(false);

  const characters = currentProject
    ? getProjectCharacters(currentProject.id)
    : [];

  const filteredCharacters = characters.filter((c) =>
    c.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const groupedCharacters = ROLES.map((r) => ({
    ...r,
    characters: filteredCharacters.filter((c) => c.role === r.id),
  })).filter((g) => g.characters.length > 0);

  const handleSaveCharacter = async () => {
    if (!currentProject || !name.trim()) {
      Alert.alert("Error", "Please enter a character name");
      return;
    }

    setIsSaving(true);
    try {
      if (editingCharacter) {
        await updateCharacter(editingCharacter.id, {
          name: name.trim(),
          role,
          age: age.trim(),
          appearance: appearance.trim(),
          personality: personality.trim(),
          backstory: backstory.trim(),
          goals: goals.trim(),
          relationships: relationships.trim(),
          notes: notes.trim(),
          avatarColor,
        });
      } else {
        await addCharacter({
          projectId: currentProject.id,
          name: name.trim(),
          role,
          age: age.trim(),
          appearance: appearance.trim(),
          personality: personality.trim(),
          backstory: backstory.trim(),
          goals: goals.trim(),
          relationships: relationships.trim(),
          notes: notes.trim(),
          avatarColor,
        });
      }
      resetForm();
    } catch (error) {
      Alert.alert("Error", "Failed to save character");
    } finally {
      setIsSaving(false);
    }
  };

  const handleEditCharacter = (character: Character) => {
    setEditingCharacter(character);
    setName(character.name);
    setRole(character.role);
    setAge(character.age);
    setAppearance(character.appearance);
    setPersonality(character.personality);
    setBackstory(character.backstory);
    setGoals(character.goals);
    setRelationships(character.relationships);
    setNotes(character.notes);
    setAvatarColor(character.avatarColor);
    setShowCharacterModal(true);
  };

  const handleDeleteCharacter = (character: Character) => {
    Alert.alert(
      "Delete Character",
      `Are you sure you want to delete "${character.name}"?`,
      [
        { text: "Cancel", style: "cancel" },
        {
          text: "Delete",
          style: "destructive",
          onPress: () => deleteCharacter(character.id),
        },
      ]
    );
  };

  const resetForm = () => {
    setShowCharacterModal(false);
    setEditingCharacter(null);
    setName("");
    setRole("supporting");
    setAge("");
    setAppearance("");
    setPersonality("");
    setBackstory("");
    setGoals("");
    setRelationships("");
    setNotes("");
    setAvatarColor(AVATAR_COLORS[Math.floor(Math.random() * AVATAR_COLORS.length)]);
  };

  if (!currentProject) {
    return (
      <ThemedView style={styles.container}>
        <View style={[styles.header, { paddingTop: insets.top + Spacing.lg }]}>
          <ThemedText type="h1">Characters</ThemedText>
        </View>
        <View style={styles.emptyContainer}>
          <Feather name="users" size={64} color={theme.textTertiary} />
          <ThemedText
            type="h3"
            style={{ color: theme.textSecondary, marginTop: Spacing.xl }}
          >
            No Project Selected
          </ThemedText>
          <ThemedText
            type="body"
            style={{
              color: theme.textTertiary,
              textAlign: "center",
              marginTop: Spacing.sm,
              paddingHorizontal: Spacing["3xl"],
            }}
          >
            Select or create a project from the Projects tab to manage
            characters
          </ThemedText>
        </View>
      </ThemedView>
    );
  }

  return (
    <ThemedView style={styles.container}>
      <View style={[styles.header, { paddingTop: insets.top + Spacing.lg }]}>
        <View style={styles.headerTop}>
          <ThemedText type="h1">Characters</ThemedText>
          <Pressable
            style={[styles.addButton, { backgroundColor: theme.primary }]}
            onPress={() => {
              setAvatarColor(AVATAR_COLORS[Math.floor(Math.random() * AVATAR_COLORS.length)]);
              setShowCharacterModal(true);
            }}
          >
            <Feather name="plus" size={20} color="#FFFFFF" />
          </Pressable>
        </View>
        <ThemedText type="small" style={{ color: theme.textSecondary }}>
          {currentProject.title}
        </ThemedText>

        <View
          style={[
            styles.searchContainer,
            { backgroundColor: theme.backgroundDefault },
          ]}
        >
          <Feather name="search" size={18} color={theme.textTertiary} />
          <TextInput
            style={[styles.searchInput, { color: theme.text }]}
            placeholder="Search characters..."
            placeholderTextColor={theme.textTertiary}
            value={searchQuery}
            onChangeText={setSearchQuery}
          />
          {searchQuery ? (
            <Pressable onPress={() => setSearchQuery("")}>
              <Feather name="x" size={18} color={theme.textTertiary} />
            </Pressable>
          ) : null}
        </View>
      </View>

      <ScreenScrollView
        contentContainerStyle={[
          styles.scrollContent,
          { paddingBottom: tabBarHeight + Spacing.xl },
        ]}
      >
        {characters.length === 0 ? (
          <View
            style={[
              styles.emptyState,
              { backgroundColor: theme.backgroundDefault },
            ]}
          >
            <Feather name="user-plus" size={48} color={theme.textTertiary} />
            <ThemedText
              type="body"
              style={{ color: theme.textSecondary, marginTop: Spacing.lg }}
            >
              No characters yet
            </ThemedText>
            <ThemedText
              type="small"
              style={{
                color: theme.textTertiary,
                textAlign: "center",
                marginTop: Spacing.sm,
              }}
            >
              Add characters to keep track of your story's cast
            </ThemedText>
          </View>
        ) : groupedCharacters.length === 0 ? (
          <View
            style={[
              styles.emptyState,
              { backgroundColor: theme.backgroundDefault },
            ]}
          >
            <Feather name="search" size={48} color={theme.textTertiary} />
            <ThemedText
              type="body"
              style={{ color: theme.textSecondary, marginTop: Spacing.lg }}
            >
              No matches found
            </ThemedText>
          </View>
        ) : (
          groupedCharacters.map((group) => (
            <View key={group.id} style={styles.roleSection}>
              <View style={styles.roleSectionHeader}>
                <View
                  style={[
                    styles.roleBadge,
                    { backgroundColor: group.color + "20" },
                  ]}
                >
                  <View
                    style={[
                      styles.roleDot,
                      { backgroundColor: group.color },
                    ]}
                  />
                  <ThemedText type="h4" style={{ color: group.color }}>
                    {group.label}
                  </ThemedText>
                </View>
                <ThemedText type="small" style={{ color: theme.textTertiary }}>
                  {group.characters.length}
                </ThemedText>
              </View>
              {group.characters.map((character) => (
                <CharacterCard
                  key={character.id}
                  character={character}
                  onPress={() => handleEditCharacter(character)}
                  onLongPress={() => handleDeleteCharacter(character)}
                  theme={theme}
                />
              ))}
            </View>
          ))
        )}
      </ScreenScrollView>

      <Modal
        visible={showCharacterModal}
        animationType="slide"
        presentationStyle="pageSheet"
        onRequestClose={resetForm}
      >
        <ThemedView style={styles.modalContainer}>
          <View style={styles.modalHeader}>
            <Pressable onPress={resetForm}>
              <ThemedText type="body" style={{ color: theme.textSecondary }}>
                Cancel
              </ThemedText>
            </Pressable>
            <ThemedText type="h3">
              {editingCharacter ? "Edit Character" : "New Character"}
            </ThemedText>
            <Pressable onPress={handleSaveCharacter} disabled={isSaving}>
              <ThemedText
                type="body"
                style={{ color: isSaving ? theme.textTertiary : theme.primary }}
              >
                {isSaving ? "Saving..." : "Save"}
              </ThemedText>
            </Pressable>
          </View>

          <ScreenKeyboardAwareScrollView contentContainerStyle={styles.modalContent}>
            <View style={styles.avatarSection}>
              <View style={[styles.largeAvatar, { backgroundColor: avatarColor }]}>
                <ThemedText type="h1" style={{ color: "#FFFFFF" }}>
                  {name ? name.charAt(0).toUpperCase() : "?"}
                </ThemedText>
              </View>
              <View style={styles.colorPicker}>
                {AVATAR_COLORS.map((color) => (
                  <Pressable
                    key={color}
                    style={[
                      styles.colorOption,
                      { backgroundColor: color },
                      avatarColor === color && styles.colorOptionSelected,
                    ]}
                    onPress={() => setAvatarColor(color)}
                  />
                ))}
              </View>
            </View>

            <View style={styles.inputGroup}>
              <ThemedText type="small" style={styles.inputLabel}>
                Name *
              </ThemedText>
              <TextInput
                style={[
                  styles.textInput,
                  {
                    backgroundColor: theme.backgroundSecondary,
                    color: theme.text,
                    borderColor: theme.border,
                  },
                ]}
                placeholder="Character name"
                placeholderTextColor={theme.textTertiary}
                value={name}
                onChangeText={setName}
              />
            </View>

            <View style={styles.inputGroup}>
              <ThemedText type="small" style={styles.inputLabel}>
                Role
              </ThemedText>
              <View style={styles.roleSelector}>
                {ROLES.map((r) => (
                  <Pressable
                    key={r.id}
                    style={[
                      styles.roleOption,
                      {
                        backgroundColor:
                          role === r.id ? r.color : theme.backgroundSecondary,
                        borderColor: role === r.id ? r.color : theme.border,
                      },
                    ]}
                    onPress={() => setRole(r.id as Character["role"])}
                  >
                    <ThemedText
                      type="small"
                      style={{ color: role === r.id ? "#FFFFFF" : theme.text }}
                    >
                      {r.label}
                    </ThemedText>
                  </Pressable>
                ))}
              </View>
            </View>

            <View style={styles.inputGroup}>
              <ThemedText type="small" style={styles.inputLabel}>
                Age
              </ThemedText>
              <TextInput
                style={[
                  styles.textInput,
                  {
                    backgroundColor: theme.backgroundSecondary,
                    color: theme.text,
                    borderColor: theme.border,
                  },
                ]}
                placeholder="Character age"
                placeholderTextColor={theme.textTertiary}
                value={age}
                onChangeText={setAge}
              />
            </View>

            <View style={styles.inputGroup}>
              <ThemedText type="small" style={styles.inputLabel}>
                Appearance
              </ThemedText>
              <TextInput
                style={[
                  styles.textInput,
                  styles.textArea,
                  {
                    backgroundColor: theme.backgroundSecondary,
                    color: theme.text,
                    borderColor: theme.border,
                  },
                ]}
                placeholder="Physical description, distinctive features..."
                placeholderTextColor={theme.textTertiary}
                value={appearance}
                onChangeText={setAppearance}
                multiline
                numberOfLines={3}
              />
            </View>

            <View style={styles.inputGroup}>
              <ThemedText type="small" style={styles.inputLabel}>
                Personality
              </ThemedText>
              <TextInput
                style={[
                  styles.textInput,
                  styles.textArea,
                  {
                    backgroundColor: theme.backgroundSecondary,
                    color: theme.text,
                    borderColor: theme.border,
                  },
                ]}
                placeholder="Traits, quirks, behavior..."
                placeholderTextColor={theme.textTertiary}
                value={personality}
                onChangeText={setPersonality}
                multiline
                numberOfLines={3}
              />
            </View>

            <View style={styles.inputGroup}>
              <ThemedText type="small" style={styles.inputLabel}>
                Backstory
              </ThemedText>
              <TextInput
                style={[
                  styles.textInput,
                  styles.textArea,
                  {
                    backgroundColor: theme.backgroundSecondary,
                    color: theme.text,
                    borderColor: theme.border,
                  },
                ]}
                placeholder="History, origin, formative experiences..."
                placeholderTextColor={theme.textTertiary}
                value={backstory}
                onChangeText={setBackstory}
                multiline
                numberOfLines={4}
              />
            </View>

            <View style={styles.inputGroup}>
              <ThemedText type="small" style={styles.inputLabel}>
                Goals & Motivations
              </ThemedText>
              <TextInput
                style={[
                  styles.textInput,
                  styles.textArea,
                  {
                    backgroundColor: theme.backgroundSecondary,
                    color: theme.text,
                    borderColor: theme.border,
                  },
                ]}
                placeholder="What drives this character..."
                placeholderTextColor={theme.textTertiary}
                value={goals}
                onChangeText={setGoals}
                multiline
                numberOfLines={3}
              />
            </View>

            <View style={styles.inputGroup}>
              <ThemedText type="small" style={styles.inputLabel}>
                Relationships
              </ThemedText>
              <TextInput
                style={[
                  styles.textInput,
                  styles.textArea,
                  {
                    backgroundColor: theme.backgroundSecondary,
                    color: theme.text,
                    borderColor: theme.border,
                  },
                ]}
                placeholder="Connections to other characters..."
                placeholderTextColor={theme.textTertiary}
                value={relationships}
                onChangeText={setRelationships}
                multiline
                numberOfLines={3}
              />
            </View>

            <View style={[styles.inputGroup, { marginBottom: Spacing["4xl"] }]}>
              <ThemedText type="small" style={styles.inputLabel}>
                Additional Notes
              </ThemedText>
              <TextInput
                style={[
                  styles.textInput,
                  styles.textArea,
                  {
                    backgroundColor: theme.backgroundSecondary,
                    color: theme.text,
                    borderColor: theme.border,
                  },
                ]}
                placeholder="Any other important details..."
                placeholderTextColor={theme.textTertiary}
                value={notes}
                onChangeText={setNotes}
                multiline
                numberOfLines={3}
              />
            </View>
          </ScreenKeyboardAwareScrollView>
        </ThemedView>
      </Modal>
    </ThemedView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    paddingHorizontal: Spacing.xl,
    paddingBottom: Spacing.md,
  },
  headerTop: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  addButton: {
    width: 40,
    height: 40,
    borderRadius: BorderRadius.full,
    justifyContent: "center",
    alignItems: "center",
  },
  searchContainer: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: Spacing.lg,
    paddingVertical: Spacing.md,
    borderRadius: BorderRadius.sm,
    marginTop: Spacing.lg,
    gap: Spacing.sm,
  },
  searchInput: {
    flex: 1,
    fontSize: 16,
    padding: 0,
  },
  emptyContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    paddingBottom: 100,
  },
  scrollContent: {
    paddingHorizontal: Spacing.xl,
  },
  emptyState: {
    alignItems: "center",
    padding: Spacing["3xl"],
    borderRadius: BorderRadius.lg,
  },
  roleSection: {
    marginBottom: Spacing.xl,
  },
  roleSectionHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: Spacing.md,
  },
  roleBadge: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: Spacing.lg,
    paddingVertical: Spacing.xs,
    borderRadius: BorderRadius.sm,
    gap: Spacing.sm,
  },
  roleDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
  },
  characterCard: {
    flexDirection: "row",
    alignItems: "center",
    padding: Spacing.lg,
    borderRadius: BorderRadius.md,
    marginBottom: Spacing.sm,
  },
  avatar: {
    width: 44,
    height: 44,
    borderRadius: 22,
    justifyContent: "center",
    alignItems: "center",
    marginRight: Spacing.md,
  },
  characterInfo: {
    flex: 1,
  },
  characterMeta: {
    flexDirection: "row",
    alignItems: "center",
    gap: Spacing.sm,
    marginTop: Spacing.xs,
  },
  roleTag: {
    paddingHorizontal: Spacing.sm,
    paddingVertical: 2,
    borderRadius: BorderRadius.xs,
  },
  modalContainer: {
    flex: 1,
  },
  modalHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingHorizontal: Spacing.xl,
    paddingTop: Spacing.xl,
    paddingBottom: Spacing.lg,
  },
  modalContent: {
    paddingHorizontal: Spacing.xl,
  },
  avatarSection: {
    alignItems: "center",
    marginBottom: Spacing.xl,
  },
  largeAvatar: {
    width: 80,
    height: 80,
    borderRadius: 40,
    justifyContent: "center",
    alignItems: "center",
    marginBottom: Spacing.lg,
  },
  colorPicker: {
    flexDirection: "row",
    gap: Spacing.sm,
  },
  colorOption: {
    width: 28,
    height: 28,
    borderRadius: 14,
  },
  colorOptionSelected: {
    borderWidth: 3,
    borderColor: "#FFFFFF",
  },
  inputGroup: {
    marginBottom: Spacing.lg,
  },
  inputLabel: {
    marginBottom: Spacing.sm,
    fontWeight: "500",
  },
  textInput: {
    height: Spacing.inputHeight,
    borderRadius: BorderRadius.sm,
    paddingHorizontal: Spacing.lg,
    fontSize: 16,
    borderWidth: 1,
  },
  textArea: {
    height: 100,
    paddingTop: Spacing.md,
    textAlignVertical: "top",
  },
  roleSelector: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: Spacing.sm,
  },
  roleOption: {
    paddingHorizontal: Spacing.lg,
    paddingVertical: Spacing.sm,
    borderRadius: BorderRadius.full,
    borderWidth: 1,
  },
});
