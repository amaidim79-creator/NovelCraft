import React, { useState, useEffect, useRef, useCallback } from "react";
import {
  View,
  StyleSheet,
  Pressable,
  TextInput,
  Modal,
  Alert,
  ScrollView,
  Keyboard,
  Platform,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useBottomTabBarHeight } from "@react-navigation/bottom-tabs";
import { Feather } from "@expo/vector-icons";
import Animated, {
  useAnimatedStyle,
  useSharedValue,
  withSpring,
  withTiming,
} from "react-native-reanimated";
import * as Haptics from "expo-haptics";

import { ThemedText } from "@/components/ThemedText";
import { ThemedView } from "@/components/ThemedView";
import { ScreenKeyboardAwareScrollView } from "@/components/ScreenKeyboardAwareScrollView";
import { Button } from "@/components/Button";
import { useTheme } from "@/hooks/useTheme";
import { useApp } from "@/context/AppContext";
import { Spacing, BorderRadius, Fonts, Typography } from "@/constants/theme";
import { Chapter } from "@/utils/storage";

const AnimatedPressable = Animated.createAnimatedComponent(Pressable);

function ChapterCard({
  chapter,
  isActive,
  onPress,
  onLongPress,
  theme,
}: {
  chapter: Chapter;
  isActive: boolean;
  onPress: () => void;
  onLongPress: () => void;
  theme: any;
}) {
  const scale = useSharedValue(1);

  const animatedStyle = useAnimatedStyle(() => ({
    transform: [{ scale: scale.value }],
  }));

  return (
    <AnimatedPressable
      onPress={onPress}
      onLongPress={onLongPress}
      onPressIn={() => {
        scale.value = withSpring(0.98, { damping: 15, stiffness: 150 });
      }}
      onPressOut={() => {
        scale.value = withSpring(1, { damping: 15, stiffness: 150 });
      }}
      style={[
        styles.chapterCard,
        {
          backgroundColor: isActive
            ? theme.primary + "20"
            : theme.backgroundDefault,
          borderColor: isActive ? theme.primary : theme.border,
        },
        animatedStyle,
      ]}
    >
      <View style={styles.chapterInfo}>
        <ThemedText type="h4" numberOfLines={1}>
          {chapter.title}
        </ThemedText>
        <ThemedText type="small" style={{ color: theme.textSecondary }}>
          {chapter.wordCount.toLocaleString()} words
        </ThemedText>
      </View>
      <Feather
        name={isActive ? "edit-2" : "chevron-right"}
        size={16}
        color={isActive ? theme.primary : theme.textTertiary}
      />
    </AnimatedPressable>
  );
}

export default function WriteScreen() {
  const { theme, isDark } = useTheme();
  const insets = useSafeAreaInsets();
  const tabBarHeight = useBottomTabBarHeight();
  const {
    currentProject,
    getProjectChapters,
    getProjectCharacters,
    addChapter,
    updateChapter,
    deleteChapter,
    updateProject,
  } = useApp();

  const [showChapters, setShowChapters] = useState(false);
  const [showNewChapter, setShowNewChapter] = useState(false);
  const [activeChapter, setActiveChapter] = useState<Chapter | null>(null);
  const [chapterContent, setChapterContent] = useState("");
  const [newChapterTitle, setNewChapterTitle] = useState("");
  const [isSaving, setIsSaving] = useState(false);
  const [showSaveIndicator, setShowSaveIndicator] = useState(false);
  const [errorWords, setErrorWords] = useState<string[]>([]);

  const autoSaveTimer = useRef<NodeJS.Timeout | null>(null);
  const lastWordCount = useRef(0);

  const chapters = currentProject
    ? getProjectChapters(currentProject.id)
    : [];
  const characters = currentProject
    ? getProjectCharacters(currentProject.id)
    : [];

  const characterNames = characters.map((c) => c.name.toLowerCase());

  useEffect(() => {
    if (chapters.length > 0 && !activeChapter) {
      const lastChapter = chapters[chapters.length - 1];
      setActiveChapter(lastChapter);
      setChapterContent(lastChapter.content);
    }
  }, [chapters, activeChapter]);

  const countWords = useCallback((text: string) => {
    return text.trim().split(/\s+/).filter((word) => word.length > 0).length;
  }, []);

  const checkCharacterNames = useCallback(
    (text: string) => {
      if (characterNames.length === 0) return;

      const words = text.split(/\s+/);
      const errors: string[] = [];

      words.forEach((word) => {
        const cleanWord = word.replace(/[.,!?;:'"]/g, "").toLowerCase();
        const isCapitalized =
          word.length > 0 && word[0] === word[0].toUpperCase();

        if (isCapitalized && cleanWord.length > 2) {
          const similarName = characterNames.find((name) => {
            const distance = levenshteinDistance(cleanWord, name);
            return distance > 0 && distance <= 2 && distance < name.length / 2;
          });

          if (similarName) {
            errors.push(word);
          }
        }
      });

      setErrorWords(errors);
    },
    [characterNames]
  );

  const levenshteinDistance = (a: string, b: string): number => {
    if (a.length === 0) return b.length;
    if (b.length === 0) return a.length;

    const matrix: number[][] = [];

    for (let i = 0; i <= b.length; i++) {
      matrix[i] = [i];
    }

    for (let j = 0; j <= a.length; j++) {
      matrix[0][j] = j;
    }

    for (let i = 1; i <= b.length; i++) {
      for (let j = 1; j <= a.length; j++) {
        if (b.charAt(i - 1) === a.charAt(j - 1)) {
          matrix[i][j] = matrix[i - 1][j - 1];
        } else {
          matrix[i][j] = Math.min(
            matrix[i - 1][j - 1] + 1,
            matrix[i][j - 1] + 1,
            matrix[i - 1][j] + 1
          );
        }
      }
    }

    return matrix[b.length][a.length];
  };

  const handleContentChange = useCallback(
    (text: string) => {
      setChapterContent(text);

      if (autoSaveTimer.current) {
        clearTimeout(autoSaveTimer.current);
      }

      autoSaveTimer.current = setTimeout(() => {
        saveChapterContent(text);
      }, 2000);

      const currentWordCount = countWords(text);
      if (
        currentWordCount > 0 &&
        currentWordCount % 500 === 0 &&
        currentWordCount > lastWordCount.current
      ) {
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      }
      lastWordCount.current = currentWordCount;

      checkCharacterNames(text);
    },
    [countWords, checkCharacterNames]
  );

  const saveChapterContent = async (content: string) => {
    if (!activeChapter || !currentProject) return;

    setIsSaving(true);
    setShowSaveIndicator(true);
    try {
      const wordCount = countWords(content);
      await updateChapter(activeChapter.id, { content, wordCount });

      const totalWords = chapters.reduce((sum, ch) => {
        if (ch.id === activeChapter.id) return sum + wordCount;
        return sum + ch.wordCount;
      }, 0);

      await updateProject(currentProject.id, { wordCount: totalWords });

      setTimeout(() => setShowSaveIndicator(false), 1500);
    } catch (error) {
      console.error("Error saving:", error);
    } finally {
      setIsSaving(false);
    }
  };

  const handleCreateChapter = async () => {
    if (!currentProject || !newChapterTitle.trim()) {
      Alert.alert("Error", "Please enter a chapter title");
      return;
    }

    setIsSaving(true);
    try {
      const maxOrder = Math.max(0, ...chapters.map((c) => c.order));
      const chapter = await addChapter({
        projectId: currentProject.id,
        title: newChapterTitle.trim(),
        content: "",
        order: maxOrder + 1,
        wordCount: 0,
      });
      setActiveChapter(chapter);
      setChapterContent("");
      setNewChapterTitle("");
      setShowNewChapter(false);
      setShowChapters(false);
    } catch (error) {
      Alert.alert("Error", "Failed to create chapter");
    } finally {
      setIsSaving(false);
    }
  };

  const handleSelectChapter = (chapter: Chapter) => {
    if (activeChapter && chapterContent !== activeChapter.content) {
      saveChapterContent(chapterContent);
    }
    setActiveChapter(chapter);
    setChapterContent(chapter.content);
    setShowChapters(false);
  };

  const handleDeleteChapter = (chapter: Chapter) => {
    Alert.alert(
      "Delete Chapter",
      `Are you sure you want to delete "${chapter.title}"?`,
      [
        { text: "Cancel", style: "cancel" },
        {
          text: "Delete",
          style: "destructive",
          onPress: async () => {
            await deleteChapter(chapter.id);
            if (activeChapter?.id === chapter.id) {
              const remaining = chapters.filter((c) => c.id !== chapter.id);
              if (remaining.length > 0) {
                setActiveChapter(remaining[remaining.length - 1]);
                setChapterContent(remaining[remaining.length - 1].content);
              } else {
                setActiveChapter(null);
                setChapterContent("");
              }
            }
          },
        },
      ]
    );
  };

  const wordCount = countWords(chapterContent);

  if (!currentProject) {
    return (
      <ThemedView style={styles.container}>
        <View style={[styles.header, { paddingTop: insets.top + Spacing.lg }]}>
          <ThemedText type="h1">Write</ThemedText>
        </View>
        <View style={styles.emptyContainer}>
          <Feather name="edit-3" size={64} color={theme.textTertiary} />
          <ThemedText
            type="h3"
            style={{ color: theme.textSecondary, marginTop: Spacing.xl }}
          >
            No Project Selected
          </ThemedText>
          <ThemedText
            type="body"
            style={{
              color: theme.textTertiary,
              textAlign: "center",
              marginTop: Spacing.sm,
              paddingHorizontal: Spacing["3xl"],
            }}
          >
            Select or create a project from the Projects tab to start writing
          </ThemedText>
        </View>
      </ThemedView>
    );
  }

  return (
    <ThemedView style={styles.container}>
      <View style={[styles.header, { paddingTop: insets.top + Spacing.md }]}>
        <View style={styles.headerRow}>
          <Pressable
            style={[styles.chapterButton, { backgroundColor: theme.backgroundDefault }]}
            onPress={() => setShowChapters(true)}
          >
            <Feather name="list" size={18} color={theme.text} />
            <ThemedText type="body" numberOfLines={1} style={{ flex: 1 }}>
              {activeChapter?.title || "Select Chapter"}
            </ThemedText>
            <Feather name="chevron-down" size={16} color={theme.textTertiary} />
          </Pressable>

          <View style={styles.headerRight}>
            {showSaveIndicator ? (
              <View style={styles.saveIndicator}>
                <Feather name="check" size={14} color={theme.success} />
                <ThemedText type="small" style={{ color: theme.success }}>
                  Saved
                </ThemedText>
              </View>
            ) : null}
            <View
              style={[
                styles.wordCountBadge,
                { backgroundColor: theme.primary + "20" },
              ]}
            >
              <ThemedText type="small" style={{ color: theme.primary }}>
                {wordCount.toLocaleString()} words
              </ThemedText>
            </View>
          </View>
        </View>
      </View>

      {activeChapter ? (
        <ScreenKeyboardAwareScrollView
          contentContainerStyle={[
            styles.editorContainer,
            { paddingBottom: tabBarHeight + Spacing.xl },
          ]}
        >
          <TextInput
            style={[
              styles.editor,
              {
                color: theme.text,
                fontFamily: Fonts.serif,
              },
            ]}
            placeholder="Begin your story..."
            placeholderTextColor={theme.textTertiary}
            value={chapterContent}
            onChangeText={handleContentChange}
            multiline
            textAlignVertical="top"
            autoCapitalize="sentences"
            autoCorrect={true}
            scrollEnabled={false}
          />
          {errorWords.length > 0 ? (
            <View
              style={[
                styles.errorBanner,
                { backgroundColor: theme.warning + "20" },
              ]}
            >
              <Feather name="alert-circle" size={14} color={theme.warning} />
              <ThemedText type="small" style={{ color: theme.warning, flex: 1 }}>
                Possible character name misspelling: {errorWords.slice(0, 3).join(", ")}
                {errorWords.length > 3 ? ` (+${errorWords.length - 3} more)` : ""}
              </ThemedText>
            </View>
          ) : null}
        </ScreenKeyboardAwareScrollView>
      ) : (
        <View style={styles.noChapterContainer}>
          <Feather name="file-plus" size={48} color={theme.textTertiary} />
          <ThemedText
            type="body"
            style={{ color: theme.textSecondary, marginTop: Spacing.lg }}
          >
            No chapters yet
          </ThemedText>
          <Pressable
            style={[styles.createChapterButton, { backgroundColor: theme.primary }]}
            onPress={() => setShowNewChapter(true)}
          >
            <Feather name="plus" size={18} color="#FFFFFF" />
            <ThemedText type="body" style={{ color: "#FFFFFF" }}>
              Create First Chapter
            </ThemedText>
          </Pressable>
        </View>
      )}

      <Modal
        visible={showChapters}
        animationType="slide"
        presentationStyle="pageSheet"
        onRequestClose={() => setShowChapters(false)}
      >
        <ThemedView style={styles.modalContainer}>
          <View style={styles.modalHeader}>
            <Pressable onPress={() => setShowChapters(false)}>
              <Feather name="x" size={24} color={theme.text} />
            </Pressable>
            <ThemedText type="h3">Chapters</ThemedText>
            <Pressable onPress={() => setShowNewChapter(true)}>
              <Feather name="plus" size={24} color={theme.primary} />
            </Pressable>
          </View>

          <ScrollView style={styles.modalContent}>
            {chapters.length === 0 ? (
              <View style={styles.emptyChapters}>
                <ThemedText type="body" style={{ color: theme.textSecondary }}>
                  No chapters yet
                </ThemedText>
                <Button
                  onPress={() => setShowNewChapter(true)}
                  style={{ marginTop: Spacing.lg }}
                >
                  Create First Chapter
                </Button>
              </View>
            ) : (
              chapters.map((chapter) => (
                <ChapterCard
                  key={chapter.id}
                  chapter={chapter}
                  isActive={activeChapter?.id === chapter.id}
                  onPress={() => handleSelectChapter(chapter)}
                  onLongPress={() => handleDeleteChapter(chapter)}
                  theme={theme}
                />
              ))
            )}
          </ScrollView>
        </ThemedView>
      </Modal>

      <Modal
        visible={showNewChapter}
        animationType="slide"
        presentationStyle="pageSheet"
        onRequestClose={() => setShowNewChapter(false)}
      >
        <ThemedView style={styles.modalContainer}>
          <View style={styles.modalHeader}>
            <Pressable onPress={() => setShowNewChapter(false)}>
              <Feather name="x" size={24} color={theme.text} />
            </Pressable>
            <ThemedText type="h3">New Chapter</ThemedText>
            <View style={{ width: 24 }} />
          </View>

          <View style={styles.modalContent}>
            <View style={styles.inputGroup}>
              <ThemedText type="small" style={styles.inputLabel}>
                Chapter Title
              </ThemedText>
              <TextInput
                style={[
                  styles.textInput,
                  {
                    backgroundColor: theme.backgroundSecondary,
                    color: theme.text,
                    borderColor: theme.border,
                  },
                ]}
                placeholder="Enter chapter title"
                placeholderTextColor={theme.textTertiary}
                value={newChapterTitle}
                onChangeText={setNewChapterTitle}
              />
            </View>

            <Button
              onPress={handleCreateChapter}
              disabled={isSaving || !newChapterTitle.trim()}
              style={{ marginTop: Spacing.xl }}
            >
              {isSaving ? "Creating..." : "Create Chapter"}
            </Button>
          </View>
        </ThemedView>
      </Modal>
    </ThemedView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    paddingHorizontal: Spacing.xl,
    paddingBottom: Spacing.md,
  },
  headerRow: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    gap: Spacing.md,
  },
  chapterButton: {
    flex: 1,
    flexDirection: "row",
    alignItems: "center",
    gap: Spacing.sm,
    paddingHorizontal: Spacing.lg,
    paddingVertical: Spacing.md,
    borderRadius: BorderRadius.sm,
  },
  headerRight: {
    flexDirection: "row",
    alignItems: "center",
    gap: Spacing.sm,
  },
  saveIndicator: {
    flexDirection: "row",
    alignItems: "center",
    gap: Spacing.xs,
  },
  wordCountBadge: {
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.xs,
    borderRadius: BorderRadius.full,
  },
  emptyContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    paddingBottom: 100,
  },
  noChapterContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  createChapterButton: {
    flexDirection: "row",
    alignItems: "center",
    gap: Spacing.sm,
    paddingHorizontal: Spacing.xl,
    paddingVertical: Spacing.md,
    borderRadius: BorderRadius.full,
    marginTop: Spacing.xl,
  },
  editorContainer: {
    paddingHorizontal: Spacing.xl,
    flexGrow: 1,
  },
  editor: {
    flex: 1,
    fontSize: Typography.editor.fontSize,
    lineHeight: 28,
    minHeight: 400,
  },
  errorBanner: {
    flexDirection: "row",
    alignItems: "center",
    gap: Spacing.sm,
    padding: Spacing.md,
    borderRadius: BorderRadius.sm,
    marginTop: Spacing.lg,
  },
  modalContainer: {
    flex: 1,
  },
  modalHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingHorizontal: Spacing.xl,
    paddingTop: Spacing.xl,
    paddingBottom: Spacing.lg,
  },
  modalContent: {
    flex: 1,
    paddingHorizontal: Spacing.xl,
  },
  emptyChapters: {
    alignItems: "center",
    paddingTop: Spacing["3xl"],
  },
  chapterCard: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    padding: Spacing.lg,
    borderRadius: BorderRadius.md,
    borderWidth: 1,
    marginBottom: Spacing.sm,
  },
  chapterInfo: {
    flex: 1,
  },
  inputGroup: {
    marginBottom: Spacing.xl,
  },
  inputLabel: {
    marginBottom: Spacing.sm,
    fontWeight: "500",
  },
  textInput: {
    height: Spacing.inputHeight,
    borderRadius: BorderRadius.sm,
    paddingHorizontal: Spacing.lg,
    fontSize: 16,
    borderWidth: 1,
  },
});
