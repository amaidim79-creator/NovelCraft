import React, { useState, useCallback } from "react";
import {
  View,
  StyleSheet,
  Pressable,
  Modal,
  TextInput,
  Alert,
  ScrollView,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useBottomTabBarHeight } from "@react-navigation/bottom-tabs";
import { Feather } from "@expo/vector-icons";
import Animated, {
  useAnimatedStyle,
  useSharedValue,
  withSpring,
} from "react-native-reanimated";

import { ThemedText } from "@/components/ThemedText";
import { ThemedView } from "@/components/ThemedView";
import { ScreenScrollView } from "@/components/ScreenScrollView";
import { ScreenKeyboardAwareScrollView } from "@/components/ScreenKeyboardAwareScrollView";
import { Button } from "@/components/Button";
import { useTheme } from "@/hooks/useTheme";
import { useApp } from "@/context/AppContext";
import { Spacing, BorderRadius } from "@/constants/theme";
import { Note } from "@/utils/storage";

const CATEGORIES = [
  { id: "world", label: "World", icon: "globe", color: "#10B981" },
  { id: "research", label: "Research", icon: "book-open", color: "#3B82F6" },
  { id: "ideas", label: "Ideas", icon: "zap", color: "#F59E0B" },
  { id: "other", label: "Other", icon: "file-text", color: "#8B5CF6" },
];

const AnimatedPressable = Animated.createAnimatedComponent(Pressable);

function NoteCard({
  note,
  onPress,
  onLongPress,
  theme,
}: {
  note: Note;
  onPress: () => void;
  onLongPress: () => void;
  theme: any;
}) {
  const scale = useSharedValue(1);
  const category = CATEGORIES.find((c) => c.id === note.category);

  const animatedStyle = useAnimatedStyle(() => ({
    transform: [{ scale: scale.value }],
  }));

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString(undefined, {
      month: "short",
      day: "numeric",
    });
  };

  return (
    <AnimatedPressable
      onPress={onPress}
      onLongPress={onLongPress}
      onPressIn={() => {
        scale.value = withSpring(0.98, { damping: 15, stiffness: 150 });
      }}
      onPressOut={() => {
        scale.value = withSpring(1, { damping: 15, stiffness: 150 });
      }}
      style={[
        styles.noteCard,
        { backgroundColor: theme.backgroundDefault },
        animatedStyle,
      ]}
    >
      <View style={styles.noteCardHeader}>
        <View
          style={[
            styles.categoryIcon,
            { backgroundColor: (category?.color || theme.primary) + "20" },
          ]}
        >
          <Feather
            name={category?.icon as any || "file-text"}
            size={16}
            color={category?.color || theme.primary}
          />
        </View>
        <ThemedText type="small" style={{ color: theme.textTertiary }}>
          {formatDate(note.updatedAt)}
        </ThemedText>
      </View>
      <ThemedText type="h4" numberOfLines={1} style={styles.noteTitle}>
        {note.title}
      </ThemedText>
      {note.content ? (
        <ThemedText
          type="small"
          numberOfLines={2}
          style={{ color: theme.textSecondary }}
        >
          {note.content}
        </ThemedText>
      ) : null}
      {note.tags.length > 0 ? (
        <View style={styles.tagContainer}>
          {note.tags.slice(0, 3).map((tag, index) => (
            <View
              key={index}
              style={[styles.tag, { backgroundColor: theme.backgroundSecondary }]}
            >
              <ThemedText type="small" style={{ color: theme.textTertiary }}>
                {tag}
              </ThemedText>
            </View>
          ))}
          {note.tags.length > 3 ? (
            <ThemedText type="small" style={{ color: theme.textTertiary }}>
              +{note.tags.length - 3}
            </ThemedText>
          ) : null}
        </View>
      ) : null}
    </AnimatedPressable>
  );
}

export default function NotesScreen() {
  const { theme, isDark } = useTheme();
  const insets = useSafeAreaInsets();
  const tabBarHeight = useBottomTabBarHeight();
  const {
    currentProject,
    getProjectNotes,
    addNote,
    updateNote,
    deleteNote,
  } = useApp();

  const [activeCategory, setActiveCategory] = useState<Note["category"] | "all">("all");
  const [showNoteModal, setShowNoteModal] = useState(false);
  const [editingNote, setEditingNote] = useState<Note | null>(null);

  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [category, setCategory] = useState<Note["category"]>("ideas");
  const [tagsInput, setTagsInput] = useState("");
  const [isSaving, setIsSaving] = useState(false);

  const notes = currentProject ? getProjectNotes(currentProject.id) : [];

  const filteredNotes =
    activeCategory === "all"
      ? notes
      : notes.filter((n) => n.category === activeCategory);

  const sortedNotes = [...filteredNotes].sort(
    (a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime()
  );

  const handleSaveNote = async () => {
    if (!currentProject || !title.trim()) {
      Alert.alert("Error", "Please enter a note title");
      return;
    }

    setIsSaving(true);
    try {
      const tags = tagsInput
        .split(",")
        .map((t) => t.trim())
        .filter((t) => t.length > 0);

      if (editingNote) {
        await updateNote(editingNote.id, {
          title: title.trim(),
          content: content.trim(),
          category,
          tags,
        });
      } else {
        await addNote({
          projectId: currentProject.id,
          title: title.trim(),
          content: content.trim(),
          category,
          tags,
        });
      }
      resetForm();
    } catch (error) {
      Alert.alert("Error", "Failed to save note");
    } finally {
      setIsSaving(false);
    }
  };

  const handleEditNote = (note: Note) => {
    setEditingNote(note);
    setTitle(note.title);
    setContent(note.content);
    setCategory(note.category);
    setTagsInput(note.tags.join(", "));
    setShowNoteModal(true);
  };

  const handleDeleteNote = (note: Note) => {
    Alert.alert(
      "Delete Note",
      `Are you sure you want to delete "${note.title}"?`,
      [
        { text: "Cancel", style: "cancel" },
        {
          text: "Delete",
          style: "destructive",
          onPress: () => deleteNote(note.id),
        },
      ]
    );
  };

  const resetForm = () => {
    setShowNoteModal(false);
    setEditingNote(null);
    setTitle("");
    setContent("");
    setCategory("ideas");
    setTagsInput("");
  };

  if (!currentProject) {
    return (
      <ThemedView style={styles.container}>
        <View style={[styles.header, { paddingTop: insets.top + Spacing.lg }]}>
          <ThemedText type="h1">Notes</ThemedText>
        </View>
        <View style={styles.emptyContainer}>
          <Feather name="file-text" size={64} color={theme.textTertiary} />
          <ThemedText
            type="h3"
            style={{ color: theme.textSecondary, marginTop: Spacing.xl }}
          >
            No Project Selected
          </ThemedText>
          <ThemedText
            type="body"
            style={{
              color: theme.textTertiary,
              textAlign: "center",
              marginTop: Spacing.sm,
              paddingHorizontal: Spacing["3xl"],
            }}
          >
            Select or create a project from the Projects tab to add notes
          </ThemedText>
        </View>
      </ThemedView>
    );
  }

  return (
    <ThemedView style={styles.container}>
      <View style={[styles.header, { paddingTop: insets.top + Spacing.lg }]}>
        <View style={styles.headerTop}>
          <ThemedText type="h1">Notes</ThemedText>
          <Pressable
            style={[styles.addButton, { backgroundColor: theme.primary }]}
            onPress={() => setShowNoteModal(true)}
          >
            <Feather name="plus" size={20} color="#FFFFFF" />
          </Pressable>
        </View>
        <ThemedText type="small" style={{ color: theme.textSecondary }}>
          {currentProject.title}
        </ThemedText>

        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          style={styles.categoryTabs}
          contentContainerStyle={styles.categoryTabsContent}
        >
          <Pressable
            style={[
              styles.categoryTab,
              {
                backgroundColor:
                  activeCategory === "all"
                    ? theme.primary
                    : theme.backgroundDefault,
              },
            ]}
            onPress={() => setActiveCategory("all")}
          >
            <ThemedText
              type="small"
              style={{
                color: activeCategory === "all" ? "#FFFFFF" : theme.text,
              }}
            >
              All
            </ThemedText>
          </Pressable>
          {CATEGORIES.map((cat) => (
            <Pressable
              key={cat.id}
              style={[
                styles.categoryTab,
                {
                  backgroundColor:
                    activeCategory === cat.id
                      ? cat.color
                      : theme.backgroundDefault,
                },
              ]}
              onPress={() => setActiveCategory(cat.id as Note["category"])}
            >
              <Feather
                name={cat.icon as any}
                size={14}
                color={activeCategory === cat.id ? "#FFFFFF" : cat.color}
              />
              <ThemedText
                type="small"
                style={{
                  color: activeCategory === cat.id ? "#FFFFFF" : theme.text,
                }}
              >
                {cat.label}
              </ThemedText>
            </Pressable>
          ))}
        </ScrollView>
      </View>

      <ScreenScrollView
        contentContainerStyle={[
          styles.scrollContent,
          { paddingBottom: tabBarHeight + Spacing.xl },
        ]}
      >
        {notes.length === 0 ? (
          <View
            style={[
              styles.emptyState,
              { backgroundColor: theme.backgroundDefault },
            ]}
          >
            <Feather name="edit" size={48} color={theme.textTertiary} />
            <ThemedText
              type="body"
              style={{ color: theme.textSecondary, marginTop: Spacing.lg }}
            >
              No notes yet
            </ThemedText>
            <ThemedText
              type="small"
              style={{
                color: theme.textTertiary,
                textAlign: "center",
                marginTop: Spacing.sm,
              }}
            >
              Add notes for world-building, research, and ideas
            </ThemedText>
          </View>
        ) : sortedNotes.length === 0 ? (
          <View
            style={[
              styles.emptyState,
              { backgroundColor: theme.backgroundDefault },
            ]}
          >
            <Feather name="inbox" size={48} color={theme.textTertiary} />
            <ThemedText
              type="body"
              style={{ color: theme.textSecondary, marginTop: Spacing.lg }}
            >
              No notes in this category
            </ThemedText>
          </View>
        ) : (
          <View style={styles.notesGrid}>
            {sortedNotes.map((note) => (
              <NoteCard
                key={note.id}
                note={note}
                onPress={() => handleEditNote(note)}
                onLongPress={() => handleDeleteNote(note)}
                theme={theme}
              />
            ))}
          </View>
        )}
      </ScreenScrollView>

      <Modal
        visible={showNoteModal}
        animationType="slide"
        presentationStyle="pageSheet"
        onRequestClose={resetForm}
      >
        <ThemedView style={styles.modalContainer}>
          <View style={styles.modalHeader}>
            <Pressable onPress={resetForm}>
              <ThemedText type="body" style={{ color: theme.textSecondary }}>
                Cancel
              </ThemedText>
            </Pressable>
            <ThemedText type="h3">
              {editingNote ? "Edit Note" : "New Note"}
            </ThemedText>
            <Pressable onPress={handleSaveNote} disabled={isSaving}>
              <ThemedText
                type="body"
                style={{ color: isSaving ? theme.textTertiary : theme.primary }}
              >
                {isSaving ? "Saving..." : "Save"}
              </ThemedText>
            </Pressable>
          </View>

          <ScreenKeyboardAwareScrollView contentContainerStyle={styles.modalContent}>
            <View style={styles.inputGroup}>
              <ThemedText type="small" style={styles.inputLabel}>
                Title *
              </ThemedText>
              <TextInput
                style={[
                  styles.textInput,
                  {
                    backgroundColor: theme.backgroundSecondary,
                    color: theme.text,
                    borderColor: theme.border,
                  },
                ]}
                placeholder="Note title"
                placeholderTextColor={theme.textTertiary}
                value={title}
                onChangeText={setTitle}
              />
            </View>

            <View style={styles.inputGroup}>
              <ThemedText type="small" style={styles.inputLabel}>
                Category
              </ThemedText>
              <View style={styles.categorySelector}>
                {CATEGORIES.map((cat) => (
                  <Pressable
                    key={cat.id}
                    style={[
                      styles.categoryOption,
                      {
                        backgroundColor:
                          category === cat.id
                            ? cat.color
                            : theme.backgroundSecondary,
                        borderColor:
                          category === cat.id ? cat.color : theme.border,
                      },
                    ]}
                    onPress={() => setCategory(cat.id as Note["category"])}
                  >
                    <Feather
                      name={cat.icon as any}
                      size={14}
                      color={category === cat.id ? "#FFFFFF" : cat.color}
                    />
                    <ThemedText
                      type="small"
                      style={{
                        color: category === cat.id ? "#FFFFFF" : theme.text,
                      }}
                    >
                      {cat.label}
                    </ThemedText>
                  </Pressable>
                ))}
              </View>
            </View>

            <View style={styles.inputGroup}>
              <ThemedText type="small" style={styles.inputLabel}>
                Content
              </ThemedText>
              <TextInput
                style={[
                  styles.textInput,
                  styles.contentArea,
                  {
                    backgroundColor: theme.backgroundSecondary,
                    color: theme.text,
                    borderColor: theme.border,
                  },
                ]}
                placeholder="Write your note here..."
                placeholderTextColor={theme.textTertiary}
                value={content}
                onChangeText={setContent}
                multiline
                numberOfLines={10}
              />
            </View>

            <View style={[styles.inputGroup, { marginBottom: Spacing["4xl"] }]}>
              <ThemedText type="small" style={styles.inputLabel}>
                Tags (comma-separated)
              </ThemedText>
              <TextInput
                style={[
                  styles.textInput,
                  {
                    backgroundColor: theme.backgroundSecondary,
                    color: theme.text,
                    borderColor: theme.border,
                  },
                ]}
                placeholder="magic, worldbuilding, lore"
                placeholderTextColor={theme.textTertiary}
                value={tagsInput}
                onChangeText={setTagsInput}
              />
            </View>
          </ScreenKeyboardAwareScrollView>
        </ThemedView>
      </Modal>
    </ThemedView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    paddingHorizontal: Spacing.xl,
    paddingBottom: Spacing.md,
  },
  headerTop: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  addButton: {
    width: 40,
    height: 40,
    borderRadius: BorderRadius.full,
    justifyContent: "center",
    alignItems: "center",
  },
  categoryTabs: {
    marginTop: Spacing.lg,
    marginHorizontal: -Spacing.xl,
  },
  categoryTabsContent: {
    paddingHorizontal: Spacing.xl,
    gap: Spacing.sm,
  },
  categoryTab: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: Spacing.lg,
    paddingVertical: Spacing.sm,
    borderRadius: BorderRadius.full,
    gap: Spacing.xs,
  },
  emptyContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    paddingBottom: 100,
  },
  scrollContent: {
    paddingHorizontal: Spacing.xl,
    paddingTop: Spacing.lg,
  },
  emptyState: {
    alignItems: "center",
    padding: Spacing["3xl"],
    borderRadius: BorderRadius.lg,
  },
  notesGrid: {
    gap: Spacing.md,
  },
  noteCard: {
    padding: Spacing.lg,
    borderRadius: BorderRadius.md,
  },
  noteCardHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: Spacing.sm,
  },
  categoryIcon: {
    width: 28,
    height: 28,
    borderRadius: BorderRadius.xs,
    justifyContent: "center",
    alignItems: "center",
  },
  noteTitle: {
    marginBottom: Spacing.xs,
  },
  tagContainer: {
    flexDirection: "row",
    alignItems: "center",
    gap: Spacing.xs,
    marginTop: Spacing.sm,
  },
  tag: {
    paddingHorizontal: Spacing.sm,
    paddingVertical: 2,
    borderRadius: BorderRadius.xs,
  },
  modalContainer: {
    flex: 1,
  },
  modalHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingHorizontal: Spacing.xl,
    paddingTop: Spacing.xl,
    paddingBottom: Spacing.lg,
  },
  modalContent: {
    paddingHorizontal: Spacing.xl,
  },
  inputGroup: {
    marginBottom: Spacing.xl,
  },
  inputLabel: {
    marginBottom: Spacing.sm,
    fontWeight: "500",
  },
  textInput: {
    height: Spacing.inputHeight,
    borderRadius: BorderRadius.sm,
    paddingHorizontal: Spacing.lg,
    fontSize: 16,
    borderWidth: 1,
  },
  contentArea: {
    height: 200,
    paddingTop: Spacing.md,
    textAlignVertical: "top",
  },
  categorySelector: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: Spacing.sm,
  },
  categoryOption: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: Spacing.lg,
    paddingVertical: Spacing.sm,
    borderRadius: BorderRadius.full,
    borderWidth: 1,
    gap: Spacing.xs,
  },
});
