import AsyncStorage from "@react-native-async-storage/async-storage";

const STORAGE_KEYS = {
  PROJECTS: "@novelcraft_projects",
  CHARACTERS: "@novelcraft_characters",
  NOTES: "@novelcraft_notes",
  PLOT_POINTS: "@novelcraft_plot_points",
  CHAPTERS: "@novelcraft_chapters",
  SETTINGS: "@novelcraft_settings",
};

export interface Project {
  id: string;
  title: string;
  genre: string;
  description: string;
  wordCount: number;
  targetWordCount: number;
  createdAt: string;
  updatedAt: string;
}

export interface Character {
  id: string;
  projectId: string;
  name: string;
  role: "protagonist" | "antagonist" | "supporting" | "minor";
  age: string;
  appearance: string;
  personality: string;
  backstory: string;
  goals: string;
  relationships: string;
  notes: string;
  avatarColor: string;
  createdAt: string;
  updatedAt: string;
}

export interface Note {
  id: string;
  projectId: string;
  title: string;
  content: string;
  category: "world" | "research" | "ideas" | "other";
  tags: string[];
  createdAt: string;
  updatedAt: string;
}

export interface PlotPoint {
  id: string;
  projectId: string;
  title: string;
  description: string;
  act: 1 | 2 | 3;
  order: number;
  type: "setup" | "rising" | "climax" | "falling" | "resolution";
  characters: string[];
  createdAt: string;
  updatedAt: string;
}

export interface Chapter {
  id: string;
  projectId: string;
  title: string;
  content: string;
  order: number;
  wordCount: number;
  createdAt: string;
  updatedAt: string;
}

export interface AppSettings {
  fontSize: number;
  autoSaveInterval: number;
  darkMode: "system" | "light" | "dark";
  currentProjectId: string | null;
}

const defaultSettings: AppSettings = {
  fontSize: 18,
  autoSaveInterval: 30000,
  darkMode: "system",
  currentProjectId: null,
};

export const generateId = (): string => {
  return Date.now().toString(36) + Math.random().toString(36).substr(2);
};

export const storage = {
  async getProjects(): Promise<Project[]> {
    try {
      const data = await AsyncStorage.getItem(STORAGE_KEYS.PROJECTS);
      return data ? JSON.parse(data) : [];
    } catch (error) {
      console.error("Error getting projects:", error);
      return [];
    }
  },

  async saveProjects(projects: Project[]): Promise<void> {
    try {
      await AsyncStorage.setItem(
        STORAGE_KEYS.PROJECTS,
        JSON.stringify(projects)
      );
    } catch (error) {
      console.error("Error saving projects:", error);
    }
  },

  async addProject(project: Omit<Project, "id" | "createdAt" | "updatedAt">): Promise<Project> {
    const projects = await this.getProjects();
    const newProject: Project = {
      ...project,
      id: generateId(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    projects.push(newProject);
    await this.saveProjects(projects);
    return newProject;
  },

  async updateProject(id: string, updates: Partial<Project>): Promise<void> {
    const projects = await this.getProjects();
    const index = projects.findIndex((p) => p.id === id);
    if (index !== -1) {
      projects[index] = {
        ...projects[index],
        ...updates,
        updatedAt: new Date().toISOString(),
      };
      await this.saveProjects(projects);
    }
  },

  async deleteProject(id: string): Promise<void> {
    const projects = await this.getProjects();
    const filtered = projects.filter((p) => p.id !== id);
    await this.saveProjects(filtered);
    const characters = await this.getCharacters();
    await this.saveCharacters(characters.filter((c) => c.projectId !== id));
    const notes = await this.getNotes();
    await this.saveNotes(notes.filter((n) => n.projectId !== id));
    const plotPoints = await this.getPlotPoints();
    await this.savePlotPoints(plotPoints.filter((p) => p.projectId !== id));
    const chapters = await this.getChapters();
    await this.saveChapters(chapters.filter((c) => c.projectId !== id));
  },

  async getCharacters(): Promise<Character[]> {
    try {
      const data = await AsyncStorage.getItem(STORAGE_KEYS.CHARACTERS);
      return data ? JSON.parse(data) : [];
    } catch (error) {
      console.error("Error getting characters:", error);
      return [];
    }
  },

  async saveCharacters(characters: Character[]): Promise<void> {
    try {
      await AsyncStorage.setItem(
        STORAGE_KEYS.CHARACTERS,
        JSON.stringify(characters)
      );
    } catch (error) {
      console.error("Error saving characters:", error);
    }
  },

  async addCharacter(
    character: Omit<Character, "id" | "createdAt" | "updatedAt">
  ): Promise<Character> {
    const characters = await this.getCharacters();
    const newCharacter: Character = {
      ...character,
      id: generateId(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    characters.push(newCharacter);
    await this.saveCharacters(characters);
    return newCharacter;
  },

  async updateCharacter(id: string, updates: Partial<Character>): Promise<void> {
    const characters = await this.getCharacters();
    const index = characters.findIndex((c) => c.id === id);
    if (index !== -1) {
      characters[index] = {
        ...characters[index],
        ...updates,
        updatedAt: new Date().toISOString(),
      };
      await this.saveCharacters(characters);
    }
  },

  async deleteCharacter(id: string): Promise<void> {
    const characters = await this.getCharacters();
    await this.saveCharacters(characters.filter((c) => c.id !== id));
  },

  async getNotes(): Promise<Note[]> {
    try {
      const data = await AsyncStorage.getItem(STORAGE_KEYS.NOTES);
      return data ? JSON.parse(data) : [];
    } catch (error) {
      console.error("Error getting notes:", error);
      return [];
    }
  },

  async saveNotes(notes: Note[]): Promise<void> {
    try {
      await AsyncStorage.setItem(STORAGE_KEYS.NOTES, JSON.stringify(notes));
    } catch (error) {
      console.error("Error saving notes:", error);
    }
  },

  async addNote(note: Omit<Note, "id" | "createdAt" | "updatedAt">): Promise<Note> {
    const notes = await this.getNotes();
    const newNote: Note = {
      ...note,
      id: generateId(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    notes.push(newNote);
    await this.saveNotes(notes);
    return newNote;
  },

  async updateNote(id: string, updates: Partial<Note>): Promise<void> {
    const notes = await this.getNotes();
    const index = notes.findIndex((n) => n.id === id);
    if (index !== -1) {
      notes[index] = {
        ...notes[index],
        ...updates,
        updatedAt: new Date().toISOString(),
      };
      await this.saveNotes(notes);
    }
  },

  async deleteNote(id: string): Promise<void> {
    const notes = await this.getNotes();
    await this.saveNotes(notes.filter((n) => n.id !== id));
  },

  async getPlotPoints(): Promise<PlotPoint[]> {
    try {
      const data = await AsyncStorage.getItem(STORAGE_KEYS.PLOT_POINTS);
      return data ? JSON.parse(data) : [];
    } catch (error) {
      console.error("Error getting plot points:", error);
      return [];
    }
  },

  async savePlotPoints(plotPoints: PlotPoint[]): Promise<void> {
    try {
      await AsyncStorage.setItem(
        STORAGE_KEYS.PLOT_POINTS,
        JSON.stringify(plotPoints)
      );
    } catch (error) {
      console.error("Error saving plot points:", error);
    }
  },

  async addPlotPoint(
    plotPoint: Omit<PlotPoint, "id" | "createdAt" | "updatedAt">
  ): Promise<PlotPoint> {
    const plotPoints = await this.getPlotPoints();
    const newPlotPoint: PlotPoint = {
      ...plotPoint,
      id: generateId(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    plotPoints.push(newPlotPoint);
    await this.savePlotPoints(plotPoints);
    return newPlotPoint;
  },

  async updatePlotPoint(id: string, updates: Partial<PlotPoint>): Promise<void> {
    const plotPoints = await this.getPlotPoints();
    const index = plotPoints.findIndex((p) => p.id === id);
    if (index !== -1) {
      plotPoints[index] = {
        ...plotPoints[index],
        ...updates,
        updatedAt: new Date().toISOString(),
      };
      await this.savePlotPoints(plotPoints);
    }
  },

  async deletePlotPoint(id: string): Promise<void> {
    const plotPoints = await this.getPlotPoints();
    await this.savePlotPoints(plotPoints.filter((p) => p.id !== id));
  },

  async getChapters(): Promise<Chapter[]> {
    try {
      const data = await AsyncStorage.getItem(STORAGE_KEYS.CHAPTERS);
      return data ? JSON.parse(data) : [];
    } catch (error) {
      console.error("Error getting chapters:", error);
      return [];
    }
  },

  async saveChapters(chapters: Chapter[]): Promise<void> {
    try {
      await AsyncStorage.setItem(STORAGE_KEYS.CHAPTERS, JSON.stringify(chapters));
    } catch (error) {
      console.error("Error saving chapters:", error);
    }
  },

  async addChapter(
    chapter: Omit<Chapter, "id" | "createdAt" | "updatedAt">
  ): Promise<Chapter> {
    const chapters = await this.getChapters();
    const newChapter: Chapter = {
      ...chapter,
      id: generateId(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    chapters.push(newChapter);
    await this.saveChapters(chapters);
    return newChapter;
  },

  async updateChapter(id: string, updates: Partial<Chapter>): Promise<void> {
    const chapters = await this.getChapters();
    const index = chapters.findIndex((c) => c.id === id);
    if (index !== -1) {
      chapters[index] = {
        ...chapters[index],
        ...updates,
        updatedAt: new Date().toISOString(),
      };
      await this.saveChapters(chapters);
    }
  },

  async deleteChapter(id: string): Promise<void> {
    const chapters = await this.getChapters();
    await this.saveChapters(chapters.filter((c) => c.id !== id));
  },

  async getSettings(): Promise<AppSettings> {
    try {
      const data = await AsyncStorage.getItem(STORAGE_KEYS.SETTINGS);
      return data ? { ...defaultSettings, ...JSON.parse(data) } : defaultSettings;
    } catch (error) {
      console.error("Error getting settings:", error);
      return defaultSettings;
    }
  },

  async saveSettings(settings: Partial<AppSettings>): Promise<void> {
    try {
      const current = await this.getSettings();
      await AsyncStorage.setItem(
        STORAGE_KEYS.SETTINGS,
        JSON.stringify({ ...current, ...settings })
      );
    } catch (error) {
      console.error("Error saving settings:", error);
    }
  },

  async clearAll(): Promise<void> {
    try {
      await AsyncStorage.multiRemove(Object.values(STORAGE_KEYS));
    } catch (error) {
      console.error("Error clearing storage:", error);
    }
  },
};
