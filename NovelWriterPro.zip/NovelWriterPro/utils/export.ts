import * as FileSystem from "expo-file-system";
import * as Sharing from "expo-sharing";
import { Project, Chapter } from "./storage";

export async function exportToText(
  project: Project,
  chapters: Chapter[]
): Promise<string> {
  const sortedChapters = [...chapters].sort((a, b) => a.order - b.order);

  let content = `${project.title}\n`;
  content += `${"=".repeat(project.title.length)}\n\n`;

  if (project.description) {
    content += `${project.description}\n\n`;
  }

  content += `Genre: ${project.genre}\n`;
  content += `Word Count: ${project.wordCount.toLocaleString()}\n\n`;
  content += `${"─".repeat(40)}\n\n`;

  for (const chapter of sortedChapters) {
    content += `${chapter.title}\n`;
    content += `${"-".repeat(chapter.title.length)}\n\n`;
    content += `${chapter.content}\n\n`;
    content += `[${chapter.wordCount.toLocaleString()} words]\n\n`;
    content += `${"─".repeat(40)}\n\n`;
  }

  content += `\n\nExported from NovelCraft\n`;
  content += `Generated on ${new Date().toLocaleDateString()}\n`;

  return content;
}

export async function exportToHTML(
  project: Project,
  chapters: Chapter[]
): Promise<string> {
  const sortedChapters = [...chapters].sort((a, b) => a.order - b.order);

  let html = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${escapeHtml(project.title)}</title>
  <style>
    :root {
      --text: #1a1a1a;
      --bg: #fafafa;
      --accent: #6366F1;
    }
    @media (prefers-color-scheme: dark) {
      :root {
        --text: #f5f5f5;
        --bg: #0f0f0f;
      }
    }
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }
    body {
      font-family: Georgia, 'Times New Roman', serif;
      font-size: 18px;
      line-height: 1.8;
      color: var(--text);
      background: var(--bg);
      max-width: 700px;
      margin: 0 auto;
      padding: 40px 20px;
    }
    .title-page {
      text-align: center;
      margin-bottom: 60px;
      padding-bottom: 40px;
      border-bottom: 2px solid var(--accent);
    }
    h1 {
      font-size: 2.5em;
      margin-bottom: 20px;
      letter-spacing: -0.5px;
    }
    .meta {
      color: #666;
      font-style: italic;
    }
    .description {
      margin-top: 20px;
      font-size: 1.1em;
    }
    .chapter {
      margin-bottom: 60px;
      page-break-after: always;
    }
    .chapter-title {
      font-size: 1.8em;
      margin-bottom: 30px;
      color: var(--accent);
    }
    .chapter-content {
      text-align: justify;
    }
    .chapter-content p {
      margin-bottom: 1.5em;
      text-indent: 2em;
    }
    .chapter-content p:first-of-type {
      text-indent: 0;
    }
    .chapter-content p:first-of-type::first-letter {
      font-size: 3em;
      float: left;
      line-height: 1;
      margin-right: 8px;
      color: var(--accent);
    }
    .word-count {
      text-align: right;
      color: #888;
      font-size: 0.85em;
      margin-top: 20px;
      font-style: italic;
    }
    .footer {
      text-align: center;
      margin-top: 60px;
      padding-top: 40px;
      border-top: 1px solid #ddd;
      color: #888;
      font-size: 0.9em;
    }
    @media print {
      body {
        max-width: 100%;
        padding: 0;
      }
      .chapter {
        page-break-before: always;
      }
    }
  </style>
</head>
<body>
  <div class="title-page">
    <h1>${escapeHtml(project.title)}</h1>
    <p class="meta">${escapeHtml(project.genre)} | ${project.wordCount.toLocaleString()} words</p>
    ${project.description ? `<p class="description">${escapeHtml(project.description)}</p>` : ""}
  </div>
`;

  for (const chapter of sortedChapters) {
    const paragraphs = chapter.content
      .split(/\n\n+/)
      .filter((p) => p.trim())
      .map((p) => `<p>${escapeHtml(p.trim())}</p>`)
      .join("\n      ");

    html += `
  <div class="chapter">
    <h2 class="chapter-title">${escapeHtml(chapter.title)}</h2>
    <div class="chapter-content">
      ${paragraphs || "<p>No content yet.</p>"}
    </div>
    <p class="word-count">${chapter.wordCount.toLocaleString()} words</p>
  </div>
`;
  }

  html += `
  <div class="footer">
    <p>Exported from NovelCraft</p>
    <p>Generated on ${new Date().toLocaleDateString()}</p>
  </div>
</body>
</html>`;

  return html;
}

function escapeHtml(text: string): string {
  return text
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

export async function shareExport(
  project: Project,
  chapters: Chapter[],
  format: "txt" | "html"
): Promise<{ success: boolean; error?: string }> {
  try {
    const isAvailable = await Sharing.isAvailableAsync();
    if (!isAvailable) {
      return { success: false, error: "Sharing is not available on this device" };
    }

    const content =
      format === "html"
        ? await exportToHTML(project, chapters)
        : await exportToText(project, chapters);

    const fileName = `${project.title.replace(/[^a-zA-Z0-9]/g, "_")}_${Date.now()}.${format}`;
    const filePath = `${FileSystem.cacheDirectory}${fileName}`;

    await FileSystem.writeAsStringAsync(filePath, content, {
      encoding: FileSystem.EncodingType.UTF8,
    });

    await Sharing.shareAsync(filePath, {
      mimeType: format === "html" ? "text/html" : "text/plain",
      dialogTitle: `Export ${project.title}`,
    });

    return { success: true };
  } catch (error) {
    console.error("Export error:", error);
    return { success: false, error: "Failed to export. Please try again." };
  }
}
