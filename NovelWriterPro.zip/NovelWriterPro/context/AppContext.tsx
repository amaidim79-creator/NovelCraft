import React, { createContext, useContext, useState, useEffect, useCallback, ReactNode } from "react";
import {
  storage,
  Project,
  Character,
  Note,
  PlotPoint,
  Chapter,
  AppSettings,
} from "@/utils/storage";

interface AppContextType {
  projects: Project[];
  characters: Character[];
  notes: Note[];
  plotPoints: PlotPoint[];
  chapters: Chapter[];
  settings: AppSettings;
  currentProject: Project | null;
  isLoading: boolean;
  setCurrentProject: (project: Project | null) => void;
  addProject: (project: Omit<Project, "id" | "createdAt" | "updatedAt">) => Promise<Project>;
  updateProject: (id: string, updates: Partial<Project>) => Promise<void>;
  deleteProject: (id: string) => Promise<void>;
  addCharacter: (character: Omit<Character, "id" | "createdAt" | "updatedAt">) => Promise<Character>;
  updateCharacter: (id: string, updates: Partial<Character>) => Promise<void>;
  deleteCharacter: (id: string) => Promise<void>;
  addNote: (note: Omit<Note, "id" | "createdAt" | "updatedAt">) => Promise<Note>;
  updateNote: (id: string, updates: Partial<Note>) => Promise<void>;
  deleteNote: (id: string) => Promise<void>;
  addPlotPoint: (plotPoint: Omit<PlotPoint, "id" | "createdAt" | "updatedAt">) => Promise<PlotPoint>;
  updatePlotPoint: (id: string, updates: Partial<PlotPoint>) => Promise<void>;
  deletePlotPoint: (id: string) => Promise<void>;
  addChapter: (chapter: Omit<Chapter, "id" | "createdAt" | "updatedAt">) => Promise<Chapter>;
  updateChapter: (id: string, updates: Partial<Chapter>) => Promise<void>;
  deleteChapter: (id: string) => Promise<void>;
  updateSettings: (settings: Partial<AppSettings>) => Promise<void>;
  refreshData: () => Promise<void>;
  getProjectCharacters: (projectId: string) => Character[];
  getProjectNotes: (projectId: string) => Note[];
  getProjectPlotPoints: (projectId: string) => PlotPoint[];
  getProjectChapters: (projectId: string) => Chapter[];
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export function AppProvider({ children }: { children: ReactNode }) {
  const [projects, setProjects] = useState<Project[]>([]);
  const [characters, setCharacters] = useState<Character[]>([]);
  const [notes, setNotes] = useState<Note[]>([]);
  const [plotPoints, setPlotPoints] = useState<PlotPoint[]>([]);
  const [chapters, setChapters] = useState<Chapter[]>([]);
  const [settings, setSettings] = useState<AppSettings>({
    fontSize: 18,
    autoSaveInterval: 30000,
    darkMode: "system",
    currentProjectId: null,
  });
  const [currentProject, setCurrentProjectState] = useState<Project | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  const refreshData = useCallback(async () => {
    try {
      const [
        loadedProjects,
        loadedCharacters,
        loadedNotes,
        loadedPlotPoints,
        loadedChapters,
        loadedSettings,
      ] = await Promise.all([
        storage.getProjects(),
        storage.getCharacters(),
        storage.getNotes(),
        storage.getPlotPoints(),
        storage.getChapters(),
        storage.getSettings(),
      ]);

      setProjects(loadedProjects);
      setCharacters(loadedCharacters);
      setNotes(loadedNotes);
      setPlotPoints(loadedPlotPoints);
      setChapters(loadedChapters);
      setSettings(loadedSettings);

      if (loadedSettings.currentProjectId) {
        const project = loadedProjects.find(
          (p) => p.id === loadedSettings.currentProjectId
        );
        setCurrentProjectState(project || null);
      }
    } catch (error) {
      console.error("Error refreshing data:", error);
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    refreshData();
  }, [refreshData]);

  const setCurrentProject = useCallback(async (project: Project | null) => {
    setCurrentProjectState(project);
    await storage.saveSettings({ currentProjectId: project?.id || null });
  }, []);

  const addProject = useCallback(
    async (project: Omit<Project, "id" | "createdAt" | "updatedAt">) => {
      const newProject = await storage.addProject(project);
      setProjects((prev) => [...prev, newProject]);
      return newProject;
    },
    []
  );

  const updateProject = useCallback(async (id: string, updates: Partial<Project>) => {
    await storage.updateProject(id, updates);
    setProjects((prev) =>
      prev.map((p) =>
        p.id === id ? { ...p, ...updates, updatedAt: new Date().toISOString() } : p
      )
    );
    if (currentProject?.id === id) {
      setCurrentProjectState((prev) =>
        prev ? { ...prev, ...updates, updatedAt: new Date().toISOString() } : null
      );
    }
  }, [currentProject]);

  const deleteProject = useCallback(async (id: string) => {
    await storage.deleteProject(id);
    setProjects((prev) => prev.filter((p) => p.id !== id));
    setCharacters((prev) => prev.filter((c) => c.projectId !== id));
    setNotes((prev) => prev.filter((n) => n.projectId !== id));
    setPlotPoints((prev) => prev.filter((p) => p.projectId !== id));
    setChapters((prev) => prev.filter((c) => c.projectId !== id));
    if (currentProject?.id === id) {
      setCurrentProjectState(null);
    }
  }, [currentProject]);

  const addCharacter = useCallback(
    async (character: Omit<Character, "id" | "createdAt" | "updatedAt">) => {
      const newCharacter = await storage.addCharacter(character);
      setCharacters((prev) => [...prev, newCharacter]);
      return newCharacter;
    },
    []
  );

  const updateCharacter = useCallback(async (id: string, updates: Partial<Character>) => {
    await storage.updateCharacter(id, updates);
    setCharacters((prev) =>
      prev.map((c) =>
        c.id === id ? { ...c, ...updates, updatedAt: new Date().toISOString() } : c
      )
    );
  }, []);

  const deleteCharacter = useCallback(async (id: string) => {
    await storage.deleteCharacter(id);
    setCharacters((prev) => prev.filter((c) => c.id !== id));
  }, []);

  const addNote = useCallback(
    async (note: Omit<Note, "id" | "createdAt" | "updatedAt">) => {
      const newNote = await storage.addNote(note);
      setNotes((prev) => [...prev, newNote]);
      return newNote;
    },
    []
  );

  const updateNote = useCallback(async (id: string, updates: Partial<Note>) => {
    await storage.updateNote(id, updates);
    setNotes((prev) =>
      prev.map((n) =>
        n.id === id ? { ...n, ...updates, updatedAt: new Date().toISOString() } : n
      )
    );
  }, []);

  const deleteNote = useCallback(async (id: string) => {
    await storage.deleteNote(id);
    setNotes((prev) => prev.filter((n) => n.id !== id));
  }, []);

  const addPlotPoint = useCallback(
    async (plotPoint: Omit<PlotPoint, "id" | "createdAt" | "updatedAt">) => {
      const newPlotPoint = await storage.addPlotPoint(plotPoint);
      setPlotPoints((prev) => [...prev, newPlotPoint]);
      return newPlotPoint;
    },
    []
  );

  const updatePlotPoint = useCallback(async (id: string, updates: Partial<PlotPoint>) => {
    await storage.updatePlotPoint(id, updates);
    setPlotPoints((prev) =>
      prev.map((p) =>
        p.id === id ? { ...p, ...updates, updatedAt: new Date().toISOString() } : p
      )
    );
  }, []);

  const deletePlotPoint = useCallback(async (id: string) => {
    await storage.deletePlotPoint(id);
    setPlotPoints((prev) => prev.filter((p) => p.id !== id));
  }, []);

  const addChapter = useCallback(
    async (chapter: Omit<Chapter, "id" | "createdAt" | "updatedAt">) => {
      const newChapter = await storage.addChapter(chapter);
      setChapters((prev) => [...prev, newChapter]);
      return newChapter;
    },
    []
  );

  const updateChapter = useCallback(async (id: string, updates: Partial<Chapter>) => {
    await storage.updateChapter(id, updates);
    setChapters((prev) =>
      prev.map((c) =>
        c.id === id ? { ...c, ...updates, updatedAt: new Date().toISOString() } : c
      )
    );
  }, []);

  const deleteChapter = useCallback(async (id: string) => {
    await storage.deleteChapter(id);
    setChapters((prev) => prev.filter((c) => c.id !== id));
  }, []);

  const updateSettings = useCallback(async (newSettings: Partial<AppSettings>) => {
    await storage.saveSettings(newSettings);
    setSettings((prev) => ({ ...prev, ...newSettings }));
  }, []);

  const getProjectCharacters = useCallback(
    (projectId: string) => characters.filter((c) => c.projectId === projectId),
    [characters]
  );

  const getProjectNotes = useCallback(
    (projectId: string) => notes.filter((n) => n.projectId === projectId),
    [notes]
  );

  const getProjectPlotPoints = useCallback(
    (projectId: string) =>
      plotPoints
        .filter((p) => p.projectId === projectId)
        .sort((a, b) => a.order - b.order),
    [plotPoints]
  );

  const getProjectChapters = useCallback(
    (projectId: string) =>
      chapters
        .filter((c) => c.projectId === projectId)
        .sort((a, b) => a.order - b.order),
    [chapters]
  );

  return (
    <AppContext.Provider
      value={{
        projects,
        characters,
        notes,
        plotPoints,
        chapters,
        settings,
        currentProject,
        isLoading,
        setCurrentProject,
        addProject,
        updateProject,
        deleteProject,
        addCharacter,
        updateCharacter,
        deleteCharacter,
        addNote,
        updateNote,
        deleteNote,
        addPlotPoint,
        updatePlotPoint,
        deletePlotPoint,
        addChapter,
        updateChapter,
        deleteChapter,
        updateSettings,
        refreshData,
        getProjectCharacters,
        getProjectNotes,
        getProjectPlotPoints,
        getProjectChapters,
      }}
    >
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error("useApp must be used within an AppProvider");
  }
  return context;
}
