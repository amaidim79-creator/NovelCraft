import React, { createContext, useContext, useState, useEffect, useCallback, ReactNode } from "react";
import AsyncStorage from "@react-native-async-storage/async-storage";

const AUTH_STORAGE_KEY = "@novelcraft_auth";

export interface User {
  id: string;
  email: string;
  name: string;
  createdAt: string;
}

interface AuthContextType {
  user: User | null;
  isLoading: boolean;
  isAuthenticated: boolean;
  signIn: (email: string, password: string) => Promise<{ success: boolean; error?: string }>;
  signUp: (email: string, password: string, name: string) => Promise<{ success: boolean; error?: string }>;
  signOut: () => Promise<void>;
  continueAsGuest: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadUser();
  }, []);

  const loadUser = async () => {
    try {
      const data = await AsyncStorage.getItem(AUTH_STORAGE_KEY);
      if (data) {
        const parsed = JSON.parse(data);
        setUser(parsed.user);
      }
    } catch (error) {
      console.error("Error loading user:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const signIn = useCallback(async (email: string, password: string) => {
    try {
      const data = await AsyncStorage.getItem(AUTH_STORAGE_KEY);
      if (data) {
        const parsed = JSON.parse(data);
        if (parsed.email === email.toLowerCase() && parsed.password === password) {
          setUser(parsed.user);
          return { success: true };
        }
      }
      return { success: false, error: "Invalid email or password" };
    } catch (error) {
      return { success: false, error: "Something went wrong" };
    }
  }, []);

  const signUp = useCallback(async (email: string, password: string, name: string) => {
    try {
      const existingData = await AsyncStorage.getItem(AUTH_STORAGE_KEY);
      if (existingData) {
        const parsed = JSON.parse(existingData);
        if (parsed.email === email.toLowerCase()) {
          return { success: false, error: "An account with this email already exists" };
        }
      }

      const newUser: User = {
        id: Date.now().toString(36) + Math.random().toString(36).substr(2),
        email: email.toLowerCase(),
        name: name.trim(),
        createdAt: new Date().toISOString(),
      };

      await AsyncStorage.setItem(
        AUTH_STORAGE_KEY,
        JSON.stringify({
          user: newUser,
          email: email.toLowerCase(),
          password,
        })
      );

      setUser(newUser);
      return { success: true };
    } catch (error) {
      return { success: false, error: "Something went wrong" };
    }
  }, []);

  const signOut = useCallback(async () => {
    setUser(null);
  }, []);

  const continueAsGuest = useCallback(async () => {
    const guestUser: User = {
      id: "guest-" + Date.now().toString(36),
      email: "guest@novelcraft.app",
      name: "Guest Writer",
      createdAt: new Date().toISOString(),
    };
    setUser(guestUser);
  }, []);

  return (
    <AuthContext.Provider
      value={{
        user,
        isLoading,
        isAuthenticated: !!user,
        signIn,
        signUp,
        signOut,
        continueAsGuest,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}
